//**********************Including Header File****************************************************************************************
//-----------------------------------------------------------------------------------------------------------------------------------
#include "DSP28x_Project.h"     // Device Headerfile and Examples Include File
#include "piccolo_lcd.h"
//-----------------------------------------------------------------------------------------------------------------------------------
//*********************Defining Variable*********************************************************************************************
//-----------------------------------------------------------------------------------------------------------------------------------
#define enset GpioDataRegs.GPBSET.bit.GPIO57              //define enable pin set
#define enclear GpioDataRegs.GPBCLEAR.bit.GPIO57          //define enable pin reset
#define rsset GpioDataRegs.GPASET.bit.GPIO15             //define rs pin set
#define rsclear GpioDataRegs.GPACLEAR.bit.GPIO15          //define rs pin reset
#define D0SET GpioDataRegs.GPASET.bit.GPIO11             //define D0 pin set
#define D0CLEAR GpioDataRegs.GPACLEAR.bit.GPIO11         //define D0 pin reset
#define D1SET GpioDataRegs.GPBSET.bit.GPIO54           //define D1 pin set
#define D1CLEAR GpioDataRegs.GPBCLEAR.bit.GPIO54          //define D1 pin reset
#define D2SET GpioDataRegs.GPBSET.bit.GPIO34              //define D2 pin set
#define D2CLEAR GpioDataRegs.GPBCLEAR.bit.GPIO34          //define D2 pin reset
#define D3SET GpioDataRegs.GPBSET.bit.GPIO39             //define D3 pin set
#define D3CLEAR GpioDataRegs.GPBCLEAR.bit.GPIO39          //define D3 pin reset
#define D4SET GpioDataRegs.GPBSET.bit.GPIO53              //define D4 pin set
#define D4CLEAR GpioDataRegs.GPBCLEAR.bit.GPIO53          //define D4 pin reset
#define D5SET GpioDataRegs.GPASET.bit.GPIO19              //define D5 pin set
#define D5CLEAR GpioDataRegs.GPACLEAR.bit.GPIO19          //define D5 pin reset
#define D6SET GpioDataRegs.GPASET.bit.GPIO7              //define D6 pin set
#define D6CLEAR GpioDataRegs.GPACLEAR.bit.GPIO7          //define D6 pin reset
#define D7SET GpioDataRegs.GPBSET.bit.GPIO44           //define D7 pin set
#define D7CLEAR GpioDataRegs.GPBCLEAR.bit.GPIO44          //define D7 pin reset
//-----------------------------------------------------------------------------------------------------------------------------------
//*************************Defining Functions Sections*******************************************************************************
//-----------------------------------------------------------------------------------------------------------------------------------
void WriteCommandLCD(unsigned char CommandByte);
void WriteDataLCD(unsigned char DataByte);
void LCDDelay(void);
void LCDDelay1600(void);
void SendByte(unsigned char Value);
unsigned short arrow_screen=0;
unsigned short cursor_count=0;
//-----------------------------------------------------------------------------------------------------------------------------------
//************************Initialize LCD*********************************************************************************************
//-----------------------------------------------------------------------------------------------------------------------------------
void InitializeLCD(void)
{
    enset = 1;                                                               //Set Enable Pin
    LCDDelay1600();                                                          //Delay
    LCDDelay1600();                                                          //Delay
    LCDDelay1600();                                                          //Delay
    LCDDelay1600();                                                          //Delay
    WriteCommandLCD(0x38);                                                   //Command to select 8 bit interface
    LCDDelay1600();                                                          //Delay
    WriteCommandLCD(0x38);                                                   //Command to select 8 bit interface
    LCDDelay();                                                              //Small delay
    WriteCommandLCD(0x38);                                                   //Command to select 8 bit interface
    LCDDelay();                                                              //Delay
    WriteCommandLCD(0x08);                                                   //Command to off cursor,display off
    WriteCommandLCD(0x01);                                                   //Command to Clear LCD
    LCDDelay1600();                                                          //Delay
    WriteCommandLCD(0x06);                                                   //Command for setting entry mode
    WriteCommandLCD(0x0f);                                                   //Command to on cursor,blink cursor
    WriteCommandLCD(0x02);                                                   //Command return the cursor to home
    LCDDelay1600();                                                          //Delay
}
//-----------------------------------------------------------------------------------------------------------------------------------
//****************************Command Write******************************************************************************************
//-----------------------------------------------------------------------------------------------------------------------------------
void WriteCommandLCD(unsigned char CommandByte)
{
    rsclear = 1;                                                             //Clear RS pin
    SendByte(CommandByte);                                                   //Send Data
    LCDDelay();                                                              //Small delay
}
//-----------------------------------------------------------------------------------------------------------------------------------
//****************************Data Send**********************************************************************************************
//-----------------------------------------------------------------------------------------------------------------------------------
void SendByte(unsigned char Value)
{
    unsigned char temp;
    if((Value & 0x01) == 0x01)
        D0SET = 1;
    else
        D0CLEAR = 1;

    if((Value & 0x02) == 0x02)
        D1SET = 1;
    else
        D1CLEAR = 1;

    if((Value & 0x04) == 0x04)
        D2SET = 1;
    else
        D2CLEAR = 1;

    if((Value & 0x08) == 0x08)
        D3SET = 1;
    else
        D3CLEAR = 1;
    if((Value & 0x10) == 0x10)
        D4SET = 1;
    else
        D4CLEAR = 1;
    if((Value & 0x20) == 0x20)
        D5SET = 1;
    else
        D5CLEAR = 1;
    if((Value & 0x40) == 0x40)
        D6SET = 1;
    else
        D6CLEAR = 1;
    if((Value & 0x80) == 0x80)
        D7SET = 1;
    else
        D7CLEAR = 1;
     enset = 1;                                                             //Set Enable pin
    for(temp=0;temp<5; temp++);
    enclear = 1;                                                            //Clear Enable pin
    LCDDelay();                                                             //Small delay
}
//-----------------------------------------------------------------------------------------------------------------------------------
//*************************************Write Data to LCD*****************************************************************************
//-----------------------------------------------------------------------------------------------------------------------------------
void WriteDataLCD(unsigned char DataByte)
{
    rsset = 1;                                                             //Set RS Pin
    SendByte(DataByte);                                                    //Send Data to LCD
    LCDDelay();                                                            //Small delay
}
//-----------------------------------------------------------------------------------------------------------------------------------
//************************************Delay Function*********************************************************************************
//-----------------------------------------------------------------------------------------------------------------------------------
void LCDDelay(void)
{
    DELAY_US(50);                                                          //50 micro seconds
}
//-----------------------------------------------------------------------------------------------------------------------------------
//***********************************Long Delay**************************************************************************************
//-----------------------------------------------------------------------------------------------------------------------------------
void LCDDelay1600(void)
{
    DELAY_US(1600);                                                        //1600 micro seconds
}
//-----------------------------------------------------------------------------------------------------------------------------------
//************************************Cursor ON**************************************************************************************
//-----------------------------------------------------------------------------------------------------------------------------------
/*void CursorON(void)
{
    WriteCommandLCD(0x0f);                                                 //Command to switch on cursor
}*/
//-----------------------------------------------------------------------------------------------------------------------------------
//************************************Cursor Off*************************************************************************************
//-----------------------------------------------------------------------------------------------------------------------------------
/*void CursorOFF(void)
{
    WriteCommandLCD(0x0c);                                                 //Command to switch off cursor
}*/
//-----------------------------------------------------------------------------------------------------------------------------------
//************************************Cursor Shift Left******************************************************************************
//-----------------------------------------------------------------------------------------------------------------------------------
/*void CursorShiftLeft(void){                                                //Command to shift the cursor to the left side
    WriteCommandLCD(0x10);
}*/
//-----------------------------------------------------------------------------------------------------------------------------------
//************************************Cursor Shift Right*****************************************************************************
//-----------------------------------------------------------------------------------------------------------------------------------
/*void CursorShiftRight(void){                                               //Command to shift the cursor to the right side
    WriteCommandLCD(0x14);
}*/
//-----------------------------------------------------------------------------------------------------------------------------------
//***********************************LCD Clear***************************************************************************************
//-----------------------------------------------------------------------------------------------------------------------------------
void lcdClear(void){
    WriteCommandLCD(0x01);                                                 //Command to clear LCD
}
//-----------------------------------------------------------------------------------------------------------------------------------
//***********************************Cursor on line 1 position 0*********************************************************************
//-----------------------------------------------------------------------------------------------------------------------------------
/*void positionOne(void){
    WriteCommandLCD(0x80);                                                 //Command to move cursor on line 1 position one
}*/
//-----------------------------------------------------------------------------------------------------------------------------------
//***********************************Cursor on line 2 position 0*********************************************************************
//-----------------------------------------------------------------------------------------------------------------------------------
/*void positionTwo(void){
    WriteCommandLCD(0xC0);                                                 //Command to move cursor on line 2 position one
}*/
//-----------------------------------------------------------------------------------------------------------------------------------
//***********************************Cursor on line 3 position 0*********************************************************************
//-----------------------------------------------------------------------------------------------------------------------------------
/*void positionThree(void){
    WriteCommandLCD(0x94);                                                //Command to move cursor on line 3 position one
}*/
//-----------------------------------------------------------------------------------------------------------------------------------
//***********************************Cursor on line 4 position 0*********************************************************************
//-----------------------------------------------------------------------------------------------------------------------------------
/*void positionFour(void){
    WriteCommandLCD(0xD4);                                                //Command to move cursor on line 4 position one
}*/
//-----------------------------------------------------------------------------------------------------------------------------------
//***********************************Display data on lcd(unused)*********************************************************************
//-----------------------------------------------------------------------------------------------------------------------------------
void DisplayLCD1(char LineNumber,int *num)
{
    int a;
    if(LineNumber ==1)
    {
        WriteCommandLCD(0x80);                                           //Select the first line
    }
    else if(LineNumber ==2)
    {
        WriteCommandLCD(0xc0);                                          //Select the second line
    }
    else if(LineNumber ==3)
    {
        WriteCommandLCD(0x94);                                          //select the third line
    }
    else if(LineNumber ==4)
    {
        WriteCommandLCD(0xD4);                                          //select the fourth line
    }
    for(a=0;a<20;a++)
    {
        WriteDataLCD(*num);                                             //display a character
        num++;                                                          //Increment pointer
    }
    return;
}
//-----------------------------------------------------------------------------------------------------------------------------------
//************************************Main function to display data on LCD***********************************************************
//-----------------------------------------------------------------------------------------------------------------------------------
void DisplayLCD(char LineNumber,int pos,char *Message){
    int a;
    if(LineNumber ==1){                                                //First Line
        WriteCommandLCD(0x80);                                         //Line One
        switch(pos){
        case 0:
            WriteCommandLCD(0x80);                                    //position one
            break;
        case 1:
            WriteCommandLCD(0x81);                                    //position two
            break;
        case 2:
            WriteCommandLCD(0x82);                                    //position three
            break;
        case 3:
            WriteCommandLCD(0x83);                                    //position four
            break;
        case 4:
            WriteCommandLCD(0x84);                                    //position five
            break;
        case 5:
            WriteCommandLCD(0x85);                                    //position six
            break;
        case 6:
            WriteCommandLCD(0x86);                                    //position seven
            break;
        case 7:
            WriteCommandLCD(0x87);                                    //position eight
            break;
        case 8:
            WriteCommandLCD(0x88);                                    //position nine
            break;
        case 9:
            WriteCommandLCD(0x89);                                    //position ten
            break;
        case 10:
            WriteCommandLCD(0x8A);                                     //position eleven
            break;
        case 11:
            WriteCommandLCD(0x8B);                                    //position twelve
            break;
        case 12:
            WriteCommandLCD(0x8C);                                    //position thirteen
            break;
        case 13:
            WriteCommandLCD(0x8D);                                   //position fourteen
            break;
        case 14:
            WriteCommandLCD(0x8E);                                   //position fifteen
            break;
        case 15:
            WriteCommandLCD(0x8F);                                    //position sixteen
            break;
        case 16:
            WriteCommandLCD(0x90);                                     //position seventeen
            break;
        case 17:
            WriteCommandLCD(0x91);                                    //position eighteen
            break;
        case 18:
            WriteCommandLCD(0x92);                                     //position nineteen
            break;
        case 19:
            WriteCommandLCD(0x93);                                     //position twenty
            break;
        default:
            WriteCommandLCD(0x80);                                      //Default: position one
            break;
        }
    }
    else if(LineNumber ==2){                                           //Second line
        WriteCommandLCD(0xC0);
        if(pos==0){                                                    //position one
            WriteCommandLCD(0xC0);
        }else if(pos==1){                                              //position two
            WriteCommandLCD(0xC1);
        }else if(pos==2){                                              //position three
            WriteCommandLCD(0xC2);
        }else if(pos==3){                                                 //position four
            WriteCommandLCD(0xC3);
        }else if(pos==4){                                              //position five
            WriteCommandLCD(0xC4);
        }else if(pos==5){                                           //position six
            WriteCommandLCD(0xC5);
        }else if(pos==6){                                           //position seven
            WriteCommandLCD(0xC6);
        }else if(pos==7){                                           //position eight
            WriteCommandLCD(0xC7);
        }else if(pos==8){                                             //position nine
            WriteCommandLCD(0xC8);
        }else if(pos==9){                                            //position ten
            WriteCommandLCD(0xC9);
        }else if(pos==10){                                          //position eleven
            WriteCommandLCD(0xCA);
        }else if(pos==11){                                          //position twelve
            WriteCommandLCD(0xCB);
        }else if(pos==12){                                          //position thirteen
            WriteCommandLCD(0xCC);
        }else if(pos==13){                                          //position fourteen
            WriteCommandLCD(0xCD);
        }else if(pos==14){                                             //position fifteen
            WriteCommandLCD(0xCE);
        }else if(pos==15){                                             //position sixteen
            WriteCommandLCD(0xCF);
        }
    }
    else if(LineNumber ==3){

        WriteCommandLCD(0x94);
        if(pos==0){                                                   //position one
            WriteCommandLCD(0x94);
        }else if(pos==1){                                            //position two
            WriteCommandLCD(0x95);
        }else if(pos==2){                                             //position three
            WriteCommandLCD(0x96);
        }else if(pos==3){                                            //position four
            WriteCommandLCD(0x97);
        }else if(pos==4){                                              //position five
            WriteCommandLCD(0x98);
        }else if(pos==5){                                              //position six
            WriteCommandLCD(0x99);
        }else if(pos==6){                                            //position seven
            WriteCommandLCD(0x9A);
        }else if(pos==7){                                             //position eight
            WriteCommandLCD(0x9B);
        }else if(pos==8){                                             //position nine
            WriteCommandLCD(0x9C);
        }else if(pos==9){                                             //position ten
            WriteCommandLCD(0x9D);
        }else if(pos==10){                                            //position eleven
            WriteCommandLCD(0x9E);
        }else if(pos==11){                                              //position twelve
            WriteCommandLCD(0x9F);
        }else if(pos==12){                                              //position thirteen
            WriteCommandLCD(0xA0);
        }else if(pos==13){                                              //position fourteen
            WriteCommandLCD(0xA1);
        }else if(pos==14){                                              //position fifteen
            WriteCommandLCD(0xA2);
        }else if(pos==15){                                                   //position sixteen
            WriteCommandLCD(0xA3);
        }
    }
    else if(LineNumber ==4){
        WriteCommandLCD(0xD4);
        if(pos==0){                                                   //position one
            WriteCommandLCD(0xD4);
        }else if(pos==1){                                            //position two
            WriteCommandLCD(0xD5);
        }else if(pos==2){                                           //position three
            WriteCommandLCD(0xD6);
        }else if(pos==3){                                            //position four
            WriteCommandLCD(0xD7);
        }else if(pos==4){                                           //position five
            WriteCommandLCD(0xD8);
        }else if(pos==5){                                        //position six
            WriteCommandLCD(0xD9);
        }else if(pos==6){                                    //position seven
            WriteCommandLCD(0xDA);
        }else if(pos==7){                                     //position eight
            WriteCommandLCD(0xDB);
        }else if(pos==8){                                     //position nine
            WriteCommandLCD(0xDC);
        }else if(pos==9){                                       //position ten
            WriteCommandLCD(0xDD);
        }else if(pos==10){                                     //position eleven
            WriteCommandLCD(0xDE);
        }else if(pos==11){                                  //position twelve
            WriteCommandLCD(0xDF);
        }else if(pos==12){                                    //position thirteen
            WriteCommandLCD(0xE0);
        }else if(pos==13){                                  //position fourteen
            WriteCommandLCD(0xE1);
        }else if(pos==14){                                 //position fifteen
            WriteCommandLCD(0xE2);
        }else if(pos==15){                                      //position sixteen
            WriteCommandLCD(0xE3);
        }
    }
    if(arrow_screen!=1 && arrow_screen!=2 && arrow_screen!=3){
        for(a=0;a<20;a++){
            WriteDataLCD(*Message);                            //Display a character
            Message++;                                         //Increment pointer

            }
    }else{
        if(arrow_screen==1){
            for(a=0;a<20;a++){
                if(a==0){
                    WriteDataLCD(1);
                    Message++;
                }else{
                    if(a==2){
                        WriteDataLCD(2);
                        Message++;
                    }
                }
                if(a!=0 && a!=2){
                   WriteDataLCD(*Message);                            //Display a character
                   Message++;                                         //Increment pointer
                   //cursor_track++;
                }

            }
        }else{
            if(arrow_screen==2){
                for(a=0;a<20;a++){
                    if(a==0){
                        WriteDataLCD(3);
                        Message++;
                    }
                    if(a!=0){
                       WriteDataLCD(*Message);                            //Display a character
                       Message++;                                         //Increment pointer
                       //cursor_track++;
                    }

                }
            }else{
                if(arrow_screen==3){
                    for(a=0;a<20;a++){
                        if(a==0){
                            WriteDataLCD(3);
                            Message++;
                        }
                        if(a!=0){
                           WriteDataLCD(*Message);                            //Display a character
                           Message++;                                         //Increment pointer
                           //cursor_track++;
                        }

                    }
                }
            }

        }
    }



    return;
    }

