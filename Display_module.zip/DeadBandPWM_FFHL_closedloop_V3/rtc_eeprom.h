/*
 * rtc_eeprom.h
 *
 *  Created on: 24-Jul-2019
 *      Author: LENOVO
 */

#ifndef RTC_EEPROM_H_
#define RTC_EEPROM_H_
void rtc_write(Uint16 location,Uint16 data);
void eeprom_write(Uint16 high_add,Uint16 low_add,Uint16 data);
Uint16 rtc_read(Uint16 location);
Uint16 eeprom_read(Uint16 high_add,Uint16 low_add);
void rtc_Init(void);
void i2c_Config(void);
void wait_delay(void);
extern int rtc_data;
#endif /* RTC_EEPROM_H_ */
