/* These module consist of various screen template for different operation's
 * screenTemp.c
 *
 *  Created on: 04-Jul-2019
 *      Author: LENOVO
 */
#include "DSP28x_Project.h"
#include "screenTemp.h"
#include "piccolo_lcd.h"
void mainScreen();//declaring prototype of function used
void fieldSetting();//declaring prototype of function used
void outputVoltage();//declaring prototype of function used
void batteryCurrent();//declaring prototype of function used
void clockRtc();//declaring prototype of function used
void batteryHealth();//declaring prototype of function used
void viewLoggedData();//declaring prototype of function used
void viewHistory();//declaring prototype of function used
void defaultscreen(); //default screen
void outputCurrent();
void setTime();
void demoStartup();  //demo screen
void LogData();
void LogDatabyDate();
void LogDatabyFault();
void FaultScreen();
void factSetting();
void factOneSetting();
void InUnderVtg();
void InOverVtg();
void outOverVtg();
void outOverAmp();
void TransTemp();
void HsTemp();
void earthLeakage();
void shortCkt();
void factsetting2();
void setSrNo();
void clrMem();
void calibration1();
void calibration2();
void calibration3();
void calInVtg();
void calOutVtg();
void calInAmp();
void calOutAmp();
void calBattChrg();
void calTxTmp();
void calDvcTmp();
void calEthLkg();
void calBattDis();
char fieldset[]="1.Field Setting         ";
char vwLogData[]="2.View Logged Data        ";
char vwHistory[]="3.View History         ";
char outVtg[]="1.Output Voltage               ";
char outAmp[]="2.Output Current               ";
char batCurrent[]="3.Battery Current              ";
char clkTime[]="1.Set Clock/RTC                   ";
char battHealth[]="4.Set Time               ";
char batHealth[]="2.Battery Health Time            ";
char setOutVtg[]="Set Output Voltage                   ";
char setOpVtgNote[]="Limit:110 - 135 V   ";
char setOutAmp[]="Set Output Current                   ";
char setOpAmpNote[]="Limit:35 - 42 Amps";
char batSetCuurent[]="set Battery Current    ";
char setBattery[]="Limit: 10 - 15 Amps  ";
char clockrtc[]="Set Time            ";
char batteryhealth[]="Set Test Time              ";
char batHealthTime[]="Start:  00:00            ";
char rtcdatatime[]="00:01:00            ";
char rtcdatadate[]="18/07/19            ";
char opoutvtg[]="00.00               ";
char opoutamp[]="00.00               ";
char batcurrent[]="00.0               ";
char blank[]="                    ";
char welcome[]="Editing section     ";
char demo[]="Demo Start-up Screen";
char logData[]="1.View by Date      ";
char logData1[]="2.View by Fault     ";
char logDatabyDate[]="View Data by Date    ";
char logDatabyDate1[]="00/00/00            ";
char logDatabyDate2[]="Last Date: DD:MM:YY ";
char logDatabyFault[]="1.Voltage           ";
char logDatabyFault1[]="2.Current           ";
char logDatabyFault2[]="3.Temperature       ";
char logDatabyFault3[]="4.Other             ";
char faultscreen[]="18/07/19            ";
char faultscreen1[]="HH:MM:SS To HH:MM:SS ";
char faultscreen2[]="Fault description";
char faultscreen3[]="Value:             ";
char factorySetting[]="1:Input Under Vtg    ";
char factorySetting1[]="2:Input Over Vtg     ";
char factorySetting2[]="3:Output Over Vtg    ";
char factorySetting3[]="4:Output Current     ";
char factorySetting4[]="5:Short Ckt Vtg     ";
char factorySetting5[]="6:Temp. Transformer  ";
char factorySetting6[]="7:Temp.HS/Device     ";
char factorySetting7[]="8:Earth Leakage       ";
char inUnderVtg[]="Input Under Voltage ";
char inUnderVtg1[]="Trip:000V Reset:000V";
char inOverVtg[]="Input Over Voltage  ";
char inOverVtg1[]="Trip:000V Reset:000V";
char OutOverVtg[]="Output Over Voltage ";
char OutOverVtg1[]="Trip:000V Reset:000V";
char OutOverAmp[]="Output Over Current ";
char OutOverAmp1[]="Trip:00 A Reset:00 A";
char shortCktvtg[]="Short Ckt Voltage      ";
char shortCktvtg1[]="Trip:00 A              ";
char TxTemp[]="Temp. Transformer   ";
char TxTemp1[]="Trip:00C Reset:00C   ";
char TempHsDevice[]="Temp.HS/Device       ";
char TempHsDevice1[]="Trip:00C Reset:00C     ";
char EarthLeakage[]="Earth Leakage         ";
char EarthLeakage1[]="ON: 00 mA OFF:00 mA ";
char serialNo[]="1.Serial.No         ";
char clearMemory[]="2.Clear Memory      ";
char calibration[]="3.Calibration       ";
char serialNo1[]="0000000             ";
char clearMemory1[]="Yes/No              ";
char calibra1[]="1.Input Voltage     ";
char calibra2[]="2.Output Voltage    ";
char calibra3[]="3.Input Current     ";
char calibra4[]="4.Output Current    ";
char calibra5[]="5.Batt Amp-Charging ";
char calibra6[]="9.Batt Amp-Discharge";
char calibrawin1[]="Input Voltage       ";
char ivtgcal[]="Raw:0000  Vtg:000.0 ";
char calibrawin2[]="Output Voltage      ";
char ovtgcal[]="Raw:0000  Vtg:000.0 ";
char calibrawin3[]="Input Current       ";
char iampcal[]="Raw:0000  Amp:00    ";
char calibrawin4[]="Output Current        ";
char Oampcal[]="Raw:0000  Amp:00    ";
char calibrawin5[]="Batt. Amp-Charging  ";
char baCrampcal[]="Raw:0000  Amp:00    ";
char calibrawin9[]="Batt.Amp-Discharge     ";
char badrampcal[]="Raw:0000  Amp:00    ";
int DataLog[11];
void mainScreen(void){//main screen function
    WriteCommandLCD(0x0F);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,fieldset);
    DisplayLCD(2,0,vwLogData);
}

void fieldSetting(void){//field setting screen function
    WriteCommandLCD(0x0F);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,outVtg);
    DisplayLCD(2,0,outAmp);
    DisplayLCD(3,0,batCurrent);
    DisplayLCD(4,0,battHealth);
}
void factSetting(void){//field setting screen function
    WriteCommandLCD(0x0F);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,factorySetting);
    DisplayLCD(2,0,factorySetting1);
    DisplayLCD(3,0,factorySetting2);
    DisplayLCD(4,0,factorySetting3);
}
void factOneSetting(void){//field setting screen function
    WriteCommandLCD(0x0F);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,factorySetting4);
    DisplayLCD(2,0,factorySetting5);
    DisplayLCD(3,0,factorySetting6);
    DisplayLCD(4,0,factorySetting7);
}

void outputVoltage(void){//output voltage setting screen function
    WriteCommandLCD(0x0C);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,setOutVtg);
    DisplayLCD(2,5,opoutvtg);
    DisplayLCD(3,0,setOpVtgNote);
}


void outputCurrent(void){//output voltage setting screen function
    WriteCommandLCD(0x0C);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,setOutAmp);
    DisplayLCD(2,5,opoutamp);
    DisplayLCD(3,0,setOpAmpNote);
}

void batteryCurrent(void){//battery current setting screen function
    WriteCommandLCD(0x0C);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,batSetCuurent);
    DisplayLCD(2,5,batcurrent);
    DisplayLCD(3,0,setBattery);
}


void clockRtc(void){//time and date setting screen function
    WriteCommandLCD(0x0C);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,clockrtc);
    DisplayLCD(2,5,rtcdatatime);
    DisplayLCD(3,5,rtcdatadate);
}

void batteryHealth(void){//battery health screen function
    WriteCommandLCD(0x0C);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,batteryhealth);
    DisplayLCD(2,0,batHealthTime);
}

void setTime(void){
    WriteCommandLCD(0x0F);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,clkTime);
    DisplayLCD(2,0,batHealth);
}

void demoStartup(void){
    WriteCommandLCD(0x0C);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,demo);
    DisplayLCD(2,0,demo);
    DisplayLCD(3,0,demo);
    DisplayLCD(4,0,demo);
}

void LogData(void){
    WriteCommandLCD(0x0F);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,logData);
    DisplayLCD(2,0,logData1);
}

void LogDatabyDate(void){
    WriteCommandLCD(0x0C);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,logDatabyDate);
    DisplayLCD(2,5,logDatabyDate1);
    DisplayLCD(3,0,logDatabyDate2);
}

void LogDatabyFault(void){
    WriteCommandLCD(0x0F);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,logDatabyFault);
    DisplayLCD(2,0,logDatabyFault1);
    DisplayLCD(3,0,logDatabyFault2);
    DisplayLCD(4,0,logDatabyFault3);
}

void FaultScreen(void){
    WriteCommandLCD(0x0C);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,faultscreen);
    DisplayLCD(2,0,faultscreen1);
    if(DataLog[9]==0x01){
        DisplayLCD(3,0,"Over Voltage        ");
    }else{
        if(DataLog[9]==0x02){
            DisplayLCD(3,0,"Over Current        ");
        }else{
            if(DataLog[9]==0x03){
                DisplayLCD(3,0,"Earth Leakage       ");
            }else{
                if(DataLog[9]==0x04){
                    DisplayLCD(3,0,"Over Temperature    ");
                }else{
                    if(DataLog[9]==0x05){
                        DisplayLCD(3,0,"Short Circuit       ");
                    }
                }
            }
        }
    }
    //DisplayLCD(3,0,faultscreen2);
    DisplayLCD(4,0,faultscreen3);
}

void InUnderVtg(void){
    WriteCommandLCD(0x0C);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,inUnderVtg);
    DisplayLCD(2,0,inUnderVtg1);
}
void InOverVtg(void){
    WriteCommandLCD(0x0C);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,inOverVtg);
    DisplayLCD(2,0,inOverVtg1);
}
void outOverVtg(void){
    WriteCommandLCD(0x0C);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,OutOverVtg);
    DisplayLCD(2,0,OutOverVtg1);
}
void outOverAmp(void){
    WriteCommandLCD(0x0C);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,OutOverAmp);
    DisplayLCD(2,0,OutOverAmp1);
}
void TransTemp(void){
    WriteCommandLCD(0x0C);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,TxTemp);
    DisplayLCD(2,0,TxTemp1);
}
void HsTemp(void){
    WriteCommandLCD(0x0C);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,TempHsDevice);
    DisplayLCD(2,0,TempHsDevice1);
}
void earthLeakage(void){
    WriteCommandLCD(0x0C);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,EarthLeakage);
    DisplayLCD(2,0,EarthLeakage1);
}
void shortCkt(void){
    WriteCommandLCD(0x0C);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,shortCktvtg);
    DisplayLCD(2,0,shortCktvtg1);
}
void factsetting2(void){
    WriteCommandLCD(0x0F);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,serialNo);
    DisplayLCD(2,0,clearMemory);
    DisplayLCD(3,0,calibration);
}
void setSrNo(void){
    WriteCommandLCD(0x0C);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(2,5,serialNo1);
}
void clrMem(void){
    WriteCommandLCD(0x0C);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(2,5,clearMemory1);
}
void calibration1(void){
    WriteCommandLCD(0x0F);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,calibra1);
    DisplayLCD(2,0,calibra2);
    DisplayLCD(3,0,calibra3);
    DisplayLCD(4,0,calibra4);
}
void calibration2(void){
    WriteCommandLCD(0x0F);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,calibra5);
    DisplayLCD(2,0,factorySetting5);
    DisplayLCD(3,0,factorySetting6);
    DisplayLCD(4,0,factorySetting7);
}
void calibration3(void){
    WriteCommandLCD(0x0F);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,calibra6);
}
void calInVtg(void){
    WriteCommandLCD(0x0C);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,calibrawin1);
    DisplayLCD(2,0,ivtgcal);
}
void calOutVtg(void){
    WriteCommandLCD(0x0C);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,calibrawin2);
    DisplayLCD(2,0,ovtgcal);
}
void calInAmp(void){
    WriteCommandLCD(0x0C);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,calibrawin3);
    DisplayLCD(2,0,iampcal);
}
void calOutAmp(void){
    WriteCommandLCD(0x0C);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,calibrawin4);
    DisplayLCD(2,0,Oampcal);
}
void calBattChrg(void){
    WriteCommandLCD(0x0C);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,calibrawin5);
    DisplayLCD(2,0,baCrampcal);
}
void calTxTmp(void){
    WriteCommandLCD(0x0C);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,TxTemp);
}
void calDvcTmp(void){
    WriteCommandLCD(0x0C);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,TempHsDevice);
}
void calEthLkg(void){
    WriteCommandLCD(0x0C);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,EarthLeakage);
}
void calBattDis(void){
    WriteCommandLCD(0x0C);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,calibrawin9);
    DisplayLCD(2,0,badrampcal);
}





