//*****************Header File Include***********************************************************************************************
//-----------------------------------------------------------------------------------------------------------------------------------
#include "DSP28x_Project.h"     // Device Headerfile and Examples Include File
#include "piccolo_lcd.h"        //Include LCD Library
#include "screenTemp.h"         //Include Screen Template
#include "rtc_eeprom.h"         //Include RTC/EEPROM Read write function
//-----------------------------------------------------------------------------------------------------------------------------------
//*****************Variable Define with value***************************************************************************************************
//-----------------------------------------------------------------------------------------------------------------------------------
#define setBackey GpioDataRegs.GPADAT.bit.GPIO0   //defining setback key
#define incKey GpioDataRegs.GPBDAT.bit.GPIO54     //defining increment key
#define decKey GpioDataRegs.GPBDAT.bit.GPIO58     //defininig decrement key
#define shiftKey GpioDataRegs.GPADAT.bit.GPIO26   //defining shift key
#define enterKey GpioDataRegs.GPBDAT.bit.GPIO56   //defining enter key
//-----------------------------------------------------------------------------------------------------------------------------------
//*****************Function defining Section*****************************************************************************************
//-----------------------------------------------------------------------------------------------------------------------------------
void lcd(void);
void update(unsigned char);
void update1(int);
void maxCount(void);
void minCount(void);
void digitBlinker(void);
void debounce(void);
void keyScan(void);
//-----------------------------------------------------------------------------------------------------------------------------------
//*****************Variable Defining Section*****************************************************************************************
//-----------------------------------------------------------------------------------------------------------------------------------
unsigned char val = 0;
int val2 = 0;
unsigned char val3 = 0;
int keyValue=1;
int curcount=0;
short datacurcount=0;
int sbone=0;
int sbtwo=0;
int sbthree=0;
int sbfour=0;
short innerdisp=0;
short tempData;
int i=0;
int dispkey=0;
int doorstatus=0;
short j=0;
char digitBlinkData=0;
char tempBlinker;
int copy=0;
Uint16 finalsecvalue=0;
Uint16 finalminvalue=0;
Uint16 finalhourvalue=0;
Uint16 finaldatevalue=0;
Uint16 finalmonthvalue=0;
Uint16 finalyearvalue=0;
short subinnerdisp=0;
short subinnerdispone=0;
int updatertc=0;
Uint16 debouncestart=0;
Uint16 open=0;
Uint16 field_set=0;
Uint16 debouncer=50;
Uint16 field_disp_lck=0;
short subdispKeyVal=0;
unsigned short scanKey=5000;
short stopKeySense=0;
short oldkeyval=0;
short maxkeyval=0;
short testkeyval=0;
Uint16 fltDisp=0;
short fltdispslk=1;
unsigned int locked=55000;
short factDispDoor=0;
short subFactDisp=0;
short MaxCurcount=0;
short caliDispDoor=0;
short subCaliDisp=0;
short inrSubCaliDisp=0;
short caliKeyVal=1;
Uint16 CaliLck=55000;
short factctrlck=0;
short fact2ctrlck=0;
short rd_ee=0;
//-----------------------------------------------------------------------------------------------------------------------------------
//*************************Key sensing for Vertical cursor Movement******************************************************************
//-----------------------------------------------------------------------------------------------------------------------------------
void keyboard(void) { //display selection cursor key


    if(incKey == 0  && stopKeySense==0 && subFactDisp==0 && subCaliDisp==0){                      //Increment key
        stopKeySense=1;
        debouncestart=1;
        debounce();
        if(incKey==0 && open==1){
            keyValue+=1;
        }
    }else if(decKey == 0  && stopKeySense==0 && subFactDisp==0){               //Decrement key
        stopKeySense=1;
        debouncestart=1;
        debounce();
        if(decKey==0 && open==1){
            keyValue-=1;
        }
    }
    if(keyValue>maxkeyval){                      //cursor jumps to position first after increment key pressed on fourth position
        keyValue=1;
    }else if(keyValue==0){               //cursor jumps to position fourth after decrement key pressed on first position
        keyValue=maxkeyval;
    }
    switch(keyValue){                    //selects cursor position
    case 1:
        WriteCommandLCD(0x80);           //Line One position
        break;
    case 2:
        WriteCommandLCD(0xC0);          //Line Two position
        break;
    case 3:
        WriteCommandLCD(0x94);         //Line Three position
        break;
    case 4:
        WriteCommandLCD(0xD4);         //Line Fourth position
        break;
    case 5:
        WriteCommandLCD(0x80);           //Line One position
        break;
    case 6:
        WriteCommandLCD(0xC0);          //Line Two position
        break;
    case 7:
        WriteCommandLCD(0x94);         //Line Three position
        break;
    case 8:
        WriteCommandLCD(0xD4);         //Line Fourth position
        break;
    case 9:
        WriteCommandLCD(0xD5);         //Line Fourth position
        break;
    default:
        WriteCommandLCD(0x80);        //By default cursor position is Line One
        break;
    }
return;
}
//-----------------------------------------------------------------------------------------------------------------------------------
//***************************Keyboard Sensing Function for all the Normal Operations*************************************************
//-----------------------------------------------------------------------------------------------------------------------------------
void disarray(void){
    if(setBackey==0 && doorstatus==1 && factDispDoor==0 && caliDispDoor==0 &&sbone==0 &&sbtwo==0 && stopKeySense==0 ||setBackey==0 && doorstatus==0 && factDispDoor==1 && caliDispDoor==0 && subFactDisp==0 && stopKeySense==0||setBackey==0 && doorstatus==0 && factDispDoor==0 && caliDispDoor==1 && subCaliDisp==0 && stopKeySense==0){
        DELAY_US(500000);
        doorstatus=0;
        factDispDoor=0;
        caliDispDoor=0;
        fact2ctrlck=0;
        locked=55000;
        CaliLck=55000;
        factctrlck=0;
        field_set=0;
        field_disp_lck=0;
        dispkey=0;
        DELAY_US(150000);
        demoStartup();
    }
    if(doorstatus==0 && factDispDoor==0 && caliDispDoor==0 ){
        if(incKey==0 ){//Factory setting 2 screen
            CaliLck-=1;
                    if(CaliLck<50000 && decKey==0){
                        if(CaliLck==0){
                            factctrlck+=1;
                        }
                    }else{
                        if(CaliLck<50000 && decKey!=0){
                            CaliLck=55000;
                        }
                    }
                }else{
                    CaliLck=55000;
                    factctrlck=0;
                }
        if(factctrlck>=10){
            caliDispDoor=1;
            doorstatus=0;
            factDispDoor=0;
        }



        if(setBackey==0 ){//factory setting screen
            locked-=1;
            if(locked<45000 && incKey==0){
                if(locked<25000 && decKey==0){
                    if(locked==0){
                        fact2ctrlck+=1;

                    }
                }
            }else{
                if(locked<2000 &&  incKey !=0 ){
                    locked=55000;
                }
            }
        }else{
            locked=55000;
            fact2ctrlck=0;
        }

        if(fact2ctrlck==2){
            factDispDoor=1;
            doorstatus=0;
            caliDispDoor=0;
            stopKeySense=1;
        }




        if(setBackey==0){//field setting screen

            debouncestart=1;
            debounce();
            if(setBackey==0 && open==1 && debouncer==1){
                field_set+=1;
                field_disp_lck=1;
            }
            if(dispkey>5){
                doorstatus=1;
                factDispDoor=0;
                caliDispDoor=0;
                stopKeySense=1;
            }
            if(doorstatus==1){
                mainScreen();
                field_disp_lck=0;
                dispkey=0;
            }
        }else{
            dispkey=0;
        }
        if(field_disp_lck==1){
            if(field_set>=20000){
                if(setBackey==0){
                    dispkey++;
                }else{
                    dispkey=0;
                    field_disp_lck=0;
                }
                field_set=0;
            }
        }
    }
    if(innerdisp==0 || subinnerdispone==2){
        maxkeyval=4;
    }
    if(doorstatus==1 && innerdisp==4 || doorstatus==1 && sbtwo==1 && subinnerdispone==0 || doorstatus==1 && sbone==0 && sbtwo==0 && sbthree==0){
        maxkeyval=2;
    }
    if(doorstatus==0 && factDispDoor==1 ){
        maxkeyval=8;
    }
    if(caliDispDoor==1 && subCaliDisp==0){
        maxkeyval=3;
    }


    if(doorstatus==0 && factDispDoor==0 && caliDispDoor==1){
        if(caliDispDoor==1 && doorstatus==0 && factDispDoor==0 && subCaliDisp==0){
            DELAY_US(200000);
            factsetting2();
        }
        if(enterKey==0 && subCaliDisp==0){
            if(keyValue==1){
                DELAY_US(150000);
                subCaliDisp=1;
                datacurcount=0;
                digitBlinkData=serialNo1[0];
                setSrNo();
            }else{
                if(keyValue==2){
                    DELAY_US(150000);
                    subCaliDisp=2;
                    datacurcount=0;                                        //selects position first of char array
                    digitBlinkData=clearMemory1[datacurcount];
                    clrMem();
                }else{
                    if(keyValue==3){
                        DELAY_US(150000);
                        subCaliDisp=3;
                        calibration1();
                    }
                }
            }
        }
        if(shiftKey==0){
            MaxCurcount++;
            if(subCaliDisp==1){
                if(MaxCurcount>7){
                    MaxCurcount=0;
                }
                switch(MaxCurcount){
                case 0:
                    WriteCommandLCD(0xC5);                                 //cursor on first position
                    datacurcount=0;                                        //selects position first of char array
                    digitBlinkData=serialNo1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;
                case 1:
                    WriteCommandLCD(0xC6);                                 //cursor on first position
                    datacurcount=1;                                        //selects position first of char array
                    digitBlinkData=serialNo1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;
                case 2:
                    WriteCommandLCD(0xC7);                                 //cursor on first position
                    datacurcount=2;                                        //selects position first of char array
                    digitBlinkData=serialNo1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;
                case 3:
                    WriteCommandLCD(0xC8);                                 //cursor on first position
                    datacurcount=3;                                        //selects position first of char array
                    digitBlinkData=serialNo1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;
                case 4:
                    WriteCommandLCD(0xC9);                                 //cursor on first position
                    datacurcount=4;                                        //selects position first of char array
                    digitBlinkData=serialNo1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;
                case 5:
                    WriteCommandLCD(0xCA);                                 //cursor on first position
                    datacurcount=5;                                        //selects position first of char array
                    digitBlinkData=serialNo1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;
                case 6:
                     WriteCommandLCD(0xCB);                                 //cursor on first position
                     datacurcount=6;                                        //selects position first of char array
                     digitBlinkData=serialNo1[datacurcount];                 //copies position first data of char array to digitBlinkData
                     break;
                default:
                     WriteCommandLCD(0xC5);                                 //cursor on first position
                     datacurcount=0;                                        //selects position first of char array
                     digitBlinkData=serialNo1[datacurcount];                 //copies position first data of char array to digitBlinkData
                     break;
                }
            }
            if(subCaliDisp==2){
                if(MaxCurcount>1){
                    MaxCurcount=0;
                }
                switch(MaxCurcount){
                case 0:
                    WriteCommandLCD(0xC5);                                 //cursor on first position
                    datacurcount=0;                                        //selects position first of char array
                    digitBlinkData=clearMemory1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;
                case 1:
                    WriteCommandLCD(0xC6);                                 //cursor on first position
                    datacurcount=4;                                        //selects position first of char array
                    digitBlinkData=clearMemory1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;
                default:
                    WriteCommandLCD(0xC5);                                 //cursor on first position
                    datacurcount=0;                                        //selects position first of char array
                    digitBlinkData=clearMemory1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;

                }
            }
            if(inrSubCaliDisp==1){
                if(MaxCurcount>3){
                    MaxCurcount=0;
                }
                switch(MaxCurcount){
                case 0:
                    WriteCommandLCD(0xCE);                                 //cursor on first position
                    datacurcount=14;                                        //selects position first of char array
                    digitBlinkData=ivtgcal[datacurcount];
                    break;
                case 1:
                    WriteCommandLCD(0xCF);                                 //cursor on first position
                    datacurcount=15;                                        //selects position first of char array
                    digitBlinkData=ivtgcal[datacurcount];
                    break;
                case 2:
                    WriteCommandLCD(0xD0);                                 //cursor on first position
                    datacurcount=16;                                        //selects position first of char array
                    digitBlinkData=ivtgcal[datacurcount];
                    break;
                case 3:
                    WriteCommandLCD(0xD2);                                 //cursor on first position
                    datacurcount=18;                                        //selects position first of char array
                    digitBlinkData=ivtgcal[datacurcount];
                    break;
                default:
                    WriteCommandLCD(0xCE);                                 //cursor on first position
                    datacurcount=14;                                        //selects position first of char array
                    digitBlinkData=ivtgcal[datacurcount];
                    break;
                }
            }
            if(inrSubCaliDisp==2){
                if(MaxCurcount>3){
                    MaxCurcount=0;
                }
                switch(MaxCurcount){
                case 0:
                    WriteCommandLCD(0xCE);                                 //cursor on first position
                    datacurcount=14;                                        //selects position first of char array
                    digitBlinkData=ovtgcal[datacurcount];
                    break;
                case 1:
                    WriteCommandLCD(0xCF);                                 //cursor on first position
                    datacurcount=15;                                        //selects position first of char array
                    digitBlinkData=ovtgcal[datacurcount];
                    break;
                case 2:
                    WriteCommandLCD(0xD0);                                 //cursor on first position
                    datacurcount=16;                                        //selects position first of char array
                    digitBlinkData=ovtgcal[datacurcount];
                    break;
                 case 3:
                    WriteCommandLCD(0xD2);                                 //cursor on first position
                    datacurcount=18;                                        //selects position first of char array
                    digitBlinkData=ovtgcal[datacurcount];
                    break;
                 default:
                    WriteCommandLCD(0xCE);                                 //cursor on first position
                    datacurcount=14;                                        //selects position first of char array
                    digitBlinkData=ovtgcal[datacurcount];
                    break;
                }
            }
            if(inrSubCaliDisp==3){
                if(MaxCurcount>1){
                    MaxCurcount=0;
                }
                switch(MaxCurcount){
                case 0:
                     WriteCommandLCD(0xCE);                                 //cursor on first position
                     datacurcount=14;                                        //selects position first of char array
                     digitBlinkData=iampcal[datacurcount];
                     break;
                 case 1:
                     WriteCommandLCD(0xCF);                                 //cursor on first position
                     datacurcount=15;                                        //selects position first of char array
                     digitBlinkData=iampcal[datacurcount];
                     break;
                 default:
                     WriteCommandLCD(0xCE);                                 //cursor on first position
                     datacurcount=14;                                        //selects position first of char array
                     digitBlinkData=iampcal[datacurcount];
                     break;
                }
            }
            if(inrSubCaliDisp==4){
                if(MaxCurcount>1){
                    MaxCurcount=0;
                }
                switch(MaxCurcount){
                case 0:
                    WriteCommandLCD(0xCE);                                 //cursor on first position
                    datacurcount=14;                                        //selects position first of char array
                    digitBlinkData=Oampcal[datacurcount];
                    break;
                case 1:
                    WriteCommandLCD(0xCF);                                 //cursor on first position
                    datacurcount=15;                                        //selects position first of char array
                    digitBlinkData=Oampcal[datacurcount];
                    break;
                default:
                    WriteCommandLCD(0xCE);                                 //cursor on first position
                    datacurcount=14;                                        //selects position first of char array
                    digitBlinkData=Oampcal[datacurcount];
                    break;
                }
            }
            if(inrSubCaliDisp==5){
                if(MaxCurcount>1){
                    MaxCurcount=0;
                }
                switch(MaxCurcount){
                case 0:
                    WriteCommandLCD(0xCE);                                 //cursor on first position
                    datacurcount=14;                                        //selects position first of char array
                    digitBlinkData=baCrampcal[datacurcount];
                    break;
                case 1:
                    WriteCommandLCD(0xCF);                                 //cursor on first position
                    datacurcount=15;                                        //selects position first of char array
                    digitBlinkData=baCrampcal[datacurcount];
                    break;
                default:
                    WriteCommandLCD(0xCE);                                 //cursor on first position
                    datacurcount=14;                                        //selects position first of char array
                    digitBlinkData=baCrampcal[datacurcount];
                    break;
                }
            }

            if(inrSubCaliDisp==9){
                if(MaxCurcount>1){
                    MaxCurcount=0;
                }
                switch(MaxCurcount){
                case 0:
                    WriteCommandLCD(0xCE);                                 //cursor on first position
                    datacurcount=14;                                        //selects position first of char array
                    digitBlinkData=badrampcal[datacurcount];
                    break;
                case 1:
                    WriteCommandLCD(0xCF);                                 //cursor on first position
                    datacurcount=15;                                        //selects position first of char array
                    digitBlinkData=badrampcal[datacurcount];
                    break;
                default:
                    WriteCommandLCD(0xCE);                                 //cursor on first position
                    datacurcount=14;                                        //selects position first of char array
                    digitBlinkData=badrampcal[datacurcount];
                    break;
                }
            }
        }
        if(setBackey==0 && subCaliDisp!=0 && inrSubCaliDisp==0){
            stopKeySense=1;
            DELAY_US(200000);

            subCaliDisp=0;
            MaxCurcount=0;
            datacurcount=0;
            caliKeyVal=1;
            factsetting2();

        }
        if(subCaliDisp==3){
            if(incKey==0 && inrSubCaliDisp==0){
                DELAY_US(150000);
                caliKeyVal+=1;
            }else{
                if(decKey==0 && inrSubCaliDisp==0){
                    DELAY_US(150000);
                    caliKeyVal-=1;
                }
            }
            if(setBackey==0 && inrSubCaliDisp!=0 ){
                inrSubCaliDisp=0;
                MaxCurcount=0;
                datacurcount=0;
            }
            if(caliKeyVal<0){
                caliKeyVal=9;
            }else{
                if(caliKeyVal==10){
                    caliKeyVal=1;
                }
            }
            switch(caliKeyVal){
            case 1:
                WriteCommandLCD(0x80);           //Line One position
                break;
            case 2:
                WriteCommandLCD(0xC0);          //Line Two position
                break;
            case 3:
                WriteCommandLCD(0x94);         //Line Three position
                break;
            case 4:
                WriteCommandLCD(0xD4);         //Line Fourth position
                break;
            case 5:
                WriteCommandLCD(0x80);           //Line One position
                break;
             case 6:
                 WriteCommandLCD(0xC0);          //Line Two position
                 break;
             case 7:
                 WriteCommandLCD(0x94);         //Line Three position
                 break;
             case 8:
                 WriteCommandLCD(0xD4);         //Line Fourth position
                 break;
             case 9:
                 WriteCommandLCD(0x80);         //Line Fourth position
                 break;
             default:
                 WriteCommandLCD(0x80);        //By default cursor position is Line One
                 break;

            }

            if(caliKeyVal<=4 && inrSubCaliDisp==0){
                DELAY_US(200000);
                calibration1();
            }else{
                if(caliKeyVal>=5 && caliKeyVal<=8 && inrSubCaliDisp==0){
                    DELAY_US(200000);
                    calibration2();
                }else{
                    if(caliKeyVal==9 && inrSubCaliDisp==0){
                        DELAY_US(200000);
                        calibration3();
                    }
                }
            }


            if(enterKey==0){
                if(caliKeyVal==1){
                    DELAY_US(150000);
                    inrSubCaliDisp=1;
                    datacurcount=14;
                    digitBlinkData=ivtgcal[14];
                    calInVtg();
                }else{
                    if(caliKeyVal==2){
                        DELAY_US(150000);
                        inrSubCaliDisp=2;
                        datacurcount=14;
                        digitBlinkData=ovtgcal[14];
                        calOutVtg();
                    }else{
                        if(caliKeyVal==3){
                            DELAY_US(150000);
                            inrSubCaliDisp=3;
                            datacurcount=14;
                            digitBlinkData=iampcal[14];
                            calInAmp();
                        }else{
                            if(caliKeyVal==4){
                                DELAY_US(150000);
                                inrSubCaliDisp=4;
                                datacurcount=14;
                                digitBlinkData=Oampcal[14];
                                calOutAmp();
                            }else{
                                if(caliKeyVal==5){
                                    DELAY_US(150000);
                                    inrSubCaliDisp=5;
                                    datacurcount=14;
                                    digitBlinkData=baCrampcal[14];
                                    calBattChrg();
                                }else{
                                    if(caliKeyVal==6){
                                        DELAY_US(150000);
                                        inrSubCaliDisp=6;
                                        calTxTmp();
                                    }else{
                                        if(caliKeyVal==7){
                                            DELAY_US(150000);
                                            inrSubCaliDisp=7;
                                            calDvcTmp();
                                        }else{
                                            if(caliKeyVal==8){
                                                DELAY_US(150000);
                                                inrSubCaliDisp=8;
                                                calEthLkg();
                                            }else{
                                                if(caliKeyVal==9){
                                                    DELAY_US(150000);
                                                    inrSubCaliDisp=9;
                                                    datacurcount=14;
                                                    digitBlinkData=badrampcal[14];
                                                    calBattDis();
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if(incKey==0 && inrSubCaliDisp==1 ){     //sensing Incrementing key for display two

                    tempData=ivtgcal[datacurcount];         //copying current string character value
                    tempData++;                                //Incrementing current cursor value by 1
                    maxCount();                                //setting maximum count to 9
                    digitBlinkData=tempData;                   //updating blinking data with current cursor value
                }
                if(decKey==0 && inrSubCaliDisp==1  ){     //sensing decrementing key for display two

                    tempData=ivtgcal[datacurcount];         //copying current string character value
                    tempData--;                                //decrementing current character value by one
                    digitBlinkData=tempData;                   //updating blinking data with current cursor value
                    minCount();                                //setting minimum count to 0
                }
                if(inrSubCaliDisp==1 ){                  //digit blink function for display two
                    tempBlinker=20;                            //character blank data
                    ivtgcal[datacurcount]=tempBlinker;      //updating blank character value to the stored string character value
                    calInVtg();                       //calling battery current  display routine
                    DELAY_US(200000);                          //Delay for 200 milliseconds
                    tempBlinker=digitBlinkData;                //copying actual character value for blinking purpose
                    ivtgcal[datacurcount]=tempBlinker;      //updating current character value to the stored string character value
                    calInVtg();                      //calling battery current display routine
                    DELAY_US(100000);                          //Delay for 100 milliseconds
                }

             if(incKey==0 && inrSubCaliDisp==2){     //sensing Incrementing key for display two
                 tempData=ovtgcal[datacurcount];         //copying current string character value
                 tempData++;                                //Incrementing current cursor value by 1
                 maxCount();                                //setting maximum count to 9
                 digitBlinkData=tempData;                   //updating blinking data with current cursor value
                 }
             if(decKey==0 && inrSubCaliDisp==2  ){     //sensing decrementing key for display two
                 tempData=ovtgcal[datacurcount];         //copying current string character value
                 tempData--;                                //decrementing current character value by one
                 digitBlinkData=tempData;                   //updating blinking data with current cursor value
                 minCount();                                //setting minimum count to 0
                 }

             if(inrSubCaliDisp==2 ){                  //digit blink function for display two
                 tempBlinker=20;                            //character blank data
                 ovtgcal[datacurcount]=tempBlinker;      //updating blank character value to the stored string character value
                 calOutVtg();                       //calling battery current  display routine
                 DELAY_US(200000);                          //Delay for 200 milliseconds
                 tempBlinker=digitBlinkData;                //copying actual character value for blinking purpose
                 ovtgcal[datacurcount]=tempBlinker;      //updating current character value to the stored string character value
                 calOutVtg();                      //calling battery current display routine
                 DELAY_US(100000);                          //Delay for 100 milliseconds
                 }

             if(incKey==0 && inrSubCaliDisp==3 ){     //sensing Incrementing key for display two
                 tempData=iampcal[datacurcount];         //copying current string character value
                 tempData++;                                //Incrementing current cursor value by 1
                 maxCount();                                //setting maximum count to 9
                 digitBlinkData=tempData;                   //updating blinking data with current cursor value
                 }
             if(decKey==0 && inrSubCaliDisp==3  ){     //sensing decrementing key for display two
                 tempData=iampcal[datacurcount];         //copying current string character value
                 tempData--;                                //decrementing current character value by one
                 digitBlinkData=tempData;                   //updating blinking data with current cursor value
                 minCount();                                //setting minimum count to 0
                 }
             if(inrSubCaliDisp==3 ){                  //digit blink function for display two
                 tempBlinker=20;                            //character blank data
                 iampcal[datacurcount]=tempBlinker;      //updating blank character value to the stored string character value
                 calInAmp();                       //calling battery current  display routine
                 DELAY_US(200000);                          //Delay for 200 milliseconds
                 tempBlinker=digitBlinkData;                //copying actual character value for blinking purpose
                 iampcal[datacurcount]=tempBlinker;      //updating current character value to the stored string character value
                 calInAmp();                      //calling battery current display routine
                 DELAY_US(100000);                          //Delay for 100 milliseconds
                 }
             if(incKey==0 && inrSubCaliDisp==4 ){     //sensing Incrementing key for display two
                 tempData=Oampcal[datacurcount];         //copying current string character value
                 tempData++;                                //Incrementing current cursor value by 1
                 maxCount();                                //setting maximum count to 9
                 digitBlinkData=tempData;                   //updating blinking data with current cursor value
                 }
             if(decKey==0 && inrSubCaliDisp==4  ){     //sensing decrementing key for display two
                 tempData=Oampcal[datacurcount];         //copying current string character value
                 tempData--;                                //decrementing current character value by one
                 digitBlinkData=tempData;                   //updating blinking data with current cursor value
                 minCount();                                //setting minimum count to 0
                 }
             if(inrSubCaliDisp==4 ){                  //digit blink function for display two
                 tempBlinker=20;                            //character blank data
                 Oampcal[datacurcount]=tempBlinker;      //updating blank character value to the stored string character value
                 calOutAmp();                     //calling battery current  display routine
                 DELAY_US(200000);                          //Delay for 200 milliseconds
                 tempBlinker=digitBlinkData;                //copying actual character value for blinking purpose
                 Oampcal[datacurcount]=tempBlinker;      //updating current character value to the stored string character value
                 calOutAmp();                      //calling battery current display routine
                 DELAY_US(100000);                          //Delay for 100 milliseconds
                 }
             if(incKey==0 && inrSubCaliDisp==5 ){     //sensing Incrementing key for display two
                 tempData=baCrampcal[datacurcount];         //copying current string character value
                 tempData++;                                //Incrementing current cursor value by 1
                 maxCount();                                //setting maximum count to 9
                 digitBlinkData=tempData;                   //updating blinking data with current cursor value
                 }
             if(decKey==0 && inrSubCaliDisp==5 ){     //sensing decrementing key for display two
                 tempData=baCrampcal[datacurcount];         //copying current string character value
                 tempData--;                                //decrementing current character value by one
                 digitBlinkData=tempData;                   //updating blinking data with current cursor value
                 minCount();                                //setting minimum count to 0
                 }
             if(inrSubCaliDisp==5 ){                  //digit blink function for display two
                 tempBlinker=20;                            //character blank data
                 baCrampcal[datacurcount]=tempBlinker;      //updating blank character value to the stored string character value
                 calBattChrg();                       //calling battery current  display routine
                 DELAY_US(200000);                          //Delay for 200 milliseconds
                 tempBlinker=digitBlinkData;                //copying actual character value for blinking purpose
                 baCrampcal[datacurcount]=tempBlinker;      //updating current character value to the stored string character value
                 calBattChrg();                      //calling battery current display routine
                 DELAY_US(100000);                          //Delay for 100 milliseconds
                 }
             if(incKey==0 && inrSubCaliDisp==9 ){     //sensing Incrementing key for display two
                 tempData=badrampcal[datacurcount];         //copying current string character value
                 tempData++;                                //Incrementing current cursor value by 1
                 maxCount();                                //setting maximum count to 9
                 digitBlinkData=tempData;                   //updating blinking data with current cursor value
                 }
             if(decKey==0 && inrSubCaliDisp==9  ){     //sensing decrementing key for display two
                 tempData=badrampcal[datacurcount];         //copying current string character value
                 tempData--;                                //decrementing current character value by one
                 digitBlinkData=tempData;                   //updating blinking data with current cursor value
                 minCount();                                //setting minimum count to 0
                 }
             if(inrSubCaliDisp==9 ){                  //digit blink function for display two
                 tempBlinker=20;                            //character blank data
                 badrampcal[datacurcount]=tempBlinker;      //updating blank character value to the stored string character value
                 calBattDis();                       //calling battery current  display routine
                 DELAY_US(200000);                          //Delay for 200 milliseconds
                 tempBlinker=digitBlinkData;                //copying actual character value for blinking purpose
                 badrampcal[datacurcount]=tempBlinker;      //updating current character value to the stored string character value
                 calBattDis();                      //calling battery current display routine
                 DELAY_US(100000);                          //Delay for 100 milliseconds
                 }
        }
        if(incKey==0 && subCaliDisp==1 ){    //sense increment key for display 1
            tempData=serialNo1[datacurcount];          //copying current string character value
            tempData++;                               //Incrementing current character value by 1
            digitBlinkData=tempData;                  //updating blinking cursor value with current character value
            maxCount();                               //setting maximum count to 9.
            }
         if(decKey==0 && subCaliDisp==1){     //sense decrement key for display 1
             tempData=serialNo1[datacurcount];           //copying current string character value
             tempData--;                                //Decrementing current character value by 1
             digitBlinkData=tempData;                   //updating blinking cursor value with current character value
             minCount();                                //setting minimum count to 0.
             }
         if(subCaliDisp==1){                  //digit blink function for display one
             tempBlinker=20;                            //character blank data
             serialNo1[datacurcount]=tempBlinker;        //updating blank character value to the stored string character value
             setSrNo();                  //calling output display routine
             DELAY_US(200000);                          //Delay for 200 milliseconds
             tempBlinker=digitBlinkData;                //copying actual character value for blinking purpose
             serialNo1[datacurcount]=tempBlinker;        //updating current character value to the stored string character value
             setSrNo();                //calling output display routine
             DELAY_US(100000);                          //Delay for 100 milliseconds
             }
         if(subCaliDisp==2){                  //digit blink function for display one
             tempBlinker=20;                            //character blank data
             clearMemory1[datacurcount]=tempBlinker;        //updating blank character value to the stored string character value
             clrMem();                  //calling output display routine
             DELAY_US(200000);                          //Delay for 200 milliseconds
             tempBlinker=digitBlinkData;                //copying actual character value for blinking purpose
             clearMemory1[datacurcount]=tempBlinker;        //updating current character value to the stored string character value
             clrMem();                //calling output display routine
             DELAY_US(100000);                          //Delay for 100 milliseconds
             }
    }

    //***************************************************Factory Setting Display***************************************************************************//
    if(doorstatus==0 && caliDispDoor==0 && factDispDoor==1){
        if(doorstatus==0 && factDispDoor==1 && subFactDisp==0){
            if(keyValue<=4 && factDispDoor==1){
                DELAY_US(200000);
                factSetting();
            }else{
                if(keyValue>=4 && factDispDoor==1 && subFactDisp==0){
                    DELAY_US(200000);
                    factOneSetting();
                }
            }
        }
        if(enterKey==0 && factDispDoor==1 && doorstatus==0){
            if(keyValue==1){
                DELAY_US(150000);
                subFactDisp=1;
                datacurcount=5;
                digitBlinkData=inUnderVtg1[5];
                InUnderVtg();
            }else{
                if(keyValue==2){
                    DELAY_US(150000);
                    subFactDisp=2;
                    digitBlinkData=inOverVtg1[5];
                    datacurcount=5;
                    InOverVtg();
                }else{
                    if(keyValue==3){
                        DELAY_US(150000);
                        subFactDisp=3;
                        datacurcount=5;
                        digitBlinkData=OutOverVtg1[5];
                        outOverVtg();
                    }else{
                        if(keyValue==4){
                            DELAY_US(150000);
                            subFactDisp=4;
                            datacurcount=5;
                            digitBlinkData=OutOverAmp1[5];
                            outOverAmp();
                        }else{
                            if(keyValue==5){
                                DELAY_US(150000);
                                subFactDisp=5;
                                datacurcount=5;
                                digitBlinkData=shortCktvtg1[5];
                                shortCkt();
                            }else{
                                if(keyValue==6){
                                    DELAY_US(150000);
                                    subFactDisp=6;
                                    datacurcount=5;
                                    digitBlinkData=TxTemp1[5];
                                    TransTemp();
                                }else{
                                    if(keyValue==7){
                                        DELAY_US(150000);
                                        subFactDisp=7;
                                        datacurcount=5;
                                        digitBlinkData=TempHsDevice1[5];
                                        HsTemp();
                                    }else{
                                        if(keyValue==8){
                                            DELAY_US(150000);
                                            subFactDisp=8;
                                            datacurcount=4;
                                            digitBlinkData=EarthLeakage1[4];
                                            earthLeakage();
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if(setBackey==0 && subFactDisp!=0){
            subFactDisp=0;
            MaxCurcount=0;
            datacurcount=0;
            stopKeySense=1;
        }
        if(shiftKey == 0 && subFactDisp!=0){
            MaxCurcount++;
            if(subFactDisp==1){
                if(MaxCurcount>5){
                    MaxCurcount=0;

                }
                switch(MaxCurcount){
                case 0:
                    WriteCommandLCD(0xC5);                                 //cursor on first position
                    datacurcount=5;                                        //selects position first of char array
                    digitBlinkData=inUnderVtg1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;
                case 1:
                    WriteCommandLCD(0xC6);                                 //cursor on first position
                    datacurcount=6;                                        //selects position first of char array
                    digitBlinkData=inUnderVtg1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;
                case 2:
                    WriteCommandLCD(0xC7);                                 //cursor on first position
                    datacurcount=7;                                        //selects position first of char array
                    digitBlinkData=inUnderVtg1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;
                case 3:
                    WriteCommandLCD(0xCF);                                 //cursor on first position
                    datacurcount=16;                                        //selects position first of char array
                    digitBlinkData=inUnderVtg1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;
                case 4:
                    WriteCommandLCD(0xD0);                                 //cursor on first position
                    datacurcount=17;                                        //selects position first of char array
                    digitBlinkData=inUnderVtg1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;
                case 5:
                    WriteCommandLCD(0xD1);                                 //cursor on first position
                    datacurcount=18;                                        //selects position first of char array
                    digitBlinkData=inUnderVtg1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;
                default:
                    WriteCommandLCD(0xC5);                                 //cursor on first position
                    datacurcount=5;                                        //selects position first of char array
                    digitBlinkData=inUnderVtg1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;

                }
            }
            if(subFactDisp==2){
                if(MaxCurcount>5){
                    MaxCurcount=0;
                }
                switch(MaxCurcount){
                case 0:
                    WriteCommandLCD(0xC5);                                 //cursor on first position
                    datacurcount=5;                                        //selects position first of char array
                    digitBlinkData=inOverVtg1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;
                case 1:
                    WriteCommandLCD(0xC6);                                 //cursor on first position
                    datacurcount=6;                                        //selects position first of char array
                    digitBlinkData=inOverVtg1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;
                case 2:
                    WriteCommandLCD(0xC7);                                 //cursor on first position
                    datacurcount=7;                                        //selects position first of char array
                    digitBlinkData=inOverVtg1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;
                case 3:
                    WriteCommandLCD(0xCF);                                 //cursor on first position
                    datacurcount=16;                                        //selects position first of char array
                    digitBlinkData=inOverVtg1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;
                case 4:
                    WriteCommandLCD(0xD0);                                 //cursor on first position
                    datacurcount=17;                                        //selects position first of char array
                    digitBlinkData=inOverVtg1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;
                case 5:
                    WriteCommandLCD(0xD1);                                 //cursor on first position
                    datacurcount=18;                                        //selects position first of char array
                    digitBlinkData=inOverVtg1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;
                default:
                    WriteCommandLCD(0xC5);                                 //cursor on first position
                    datacurcount=5;                                        //selects position first of char array
                    digitBlinkData=inOverVtg1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;
                }
            }
            if(subFactDisp==3){
                if(MaxCurcount>5){
                    MaxCurcount=0;
                }
                switch(MaxCurcount){
                case 0:
                    WriteCommandLCD(0xC5);                                 //cursor on first position
                    datacurcount=5;                                        //selects position first of char array
                    digitBlinkData=OutOverVtg1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;
                 case 1:
                    WriteCommandLCD(0xC6);                                 //cursor on first position
                    datacurcount=6;                                        //selects position first of char array
                    digitBlinkData=OutOverVtg1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;
                 case 2:
                    WriteCommandLCD(0xC7);                                 //cursor on first position
                    datacurcount=7;                                        //selects position first of char array
                    digitBlinkData=OutOverVtg1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;
                 case 3:
                    WriteCommandLCD(0xCF);                                 //cursor on first position
                    datacurcount=16;                                        //selects position first of char array
                    digitBlinkData=OutOverVtg1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;
                 case 4:
                    WriteCommandLCD(0xD0);                                 //cursor on first position
                    datacurcount=17;                                        //selects position first of char array
                    digitBlinkData=OutOverVtg1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;
                 case 5:
                    WriteCommandLCD(0xD1);                                 //cursor on first position
                    datacurcount=18;                                        //selects position first of char array
                    digitBlinkData=OutOverVtg1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;
                 default:
                    WriteCommandLCD(0xC5);                                 //cursor on first position
                    datacurcount=5;                                        //selects position first of char array
                    digitBlinkData=OutOverVtg1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;
                }
            }
            if(subFactDisp==4){
                if(MaxCurcount>3){
                    MaxCurcount=0;
                }
                switch(MaxCurcount){
                case 0:
                    WriteCommandLCD(0xC5);                                 //cursor on first position
                    datacurcount=5;                                        //selects position first of char array
                    digitBlinkData=OutOverAmp1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;
                case 1:
                    WriteCommandLCD(0xC6);                                 //cursor on first position
                    datacurcount=6;                                        //selects position first of char array
                    digitBlinkData=OutOverAmp1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;
                case 2:
                    WriteCommandLCD(0xCF);                                 //cursor on first position
                    datacurcount=7;                                        //selects position first of char array
                    digitBlinkData=OutOverAmp1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;
                case 3:
                    WriteCommandLCD(0xD0);                                 //cursor on first position
                    datacurcount=16;                                        //selects position first of char array
                    digitBlinkData=OutOverAmp1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;
                default:
                    WriteCommandLCD(0xC5);                                 //cursor on first position
                    datacurcount=5;                                        //selects position first of char array
                    digitBlinkData=OutOverAmp1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;
                }
            }
            if(subFactDisp==5){
                if(MaxCurcount>2){
                    MaxCurcount=0;
                }
                switch(MaxCurcount){
                case 0:
                    WriteCommandLCD(0xC5);                                 //cursor on first position
                    datacurcount=5;                                        //selects position first of char array
                    digitBlinkData=shortCktvtg1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;
                case 1:
                    WriteCommandLCD(0xC6);                                 //cursor on first position
                    datacurcount=6;                                        //selects position first of char array
                    digitBlinkData=shortCktvtg1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;
                default:
                    WriteCommandLCD(0xC5);                                 //cursor on first position
                    datacurcount=5;                                        //selects position first of char array
                    digitBlinkData=shortCktvtg1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;
                }
            }
            if(subFactDisp==6){
                if(MaxCurcount>3){
                    MaxCurcount=0;
                }
                switch(MaxCurcount){
                case 0:
                    WriteCommandLCD(0xC5);                                 //cursor on first position
                    datacurcount=5;                                        //selects position first of char array
                    digitBlinkData=TxTemp1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;
                case 1:
                    WriteCommandLCD(0xC6);                                 //cursor on first position
                    datacurcount=6;                                        //selects position first of char array
                    digitBlinkData=TxTemp1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;
                case 2:
                    WriteCommandLCD(0xCF);                                 //cursor on first position
                    datacurcount=7;                                        //selects position first of char array
                    digitBlinkData=TxTemp1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;
                case 3:
                    WriteCommandLCD(0xD0);                                 //cursor on first position
                    datacurcount=16;                                        //selects position first of char array
                    digitBlinkData=TxTemp1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;
                default:
                    WriteCommandLCD(0xC5);                                 //cursor on first position
                    datacurcount=5;                                        //selects position first of char array
                    digitBlinkData=TxTemp1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;
                }
            }
            if(subFactDisp==7){
                if(MaxCurcount>3){
                    MaxCurcount=0;
                }
                switch(MaxCurcount){
                case 0:
                    WriteCommandLCD(0xC5);                                 //cursor on first position
                    datacurcount=5;                                        //selects position first of char array
                    digitBlinkData=TempHsDevice1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;
                case 1:
                    WriteCommandLCD(0xC6);                                 //cursor on first position
                    datacurcount=6;                                        //selects position first of char array
                    digitBlinkData=TempHsDevice1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;
                case 2:
                    WriteCommandLCD(0xCF);                                 //cursor on first position
                    datacurcount=7;                                        //selects position first of char array
                    digitBlinkData=TempHsDevice1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;
                case 3:
                    WriteCommandLCD(0xD0);                                 //cursor on first position
                    datacurcount=16;                                        //selects position first of char array
                    digitBlinkData=TempHsDevice1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;
                default:
                    WriteCommandLCD(0xC5);                                 //cursor on first position
                    datacurcount=5;                                        //selects position first of char array
                    digitBlinkData=TempHsDevice1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;
                }
            }
            if(subFactDisp==8){
                if(MaxCurcount>3){
                    MaxCurcount=0;
                }
                switch(MaxCurcount){
                case 0:
                    WriteCommandLCD(0xC4);                                 //cursor on first position
                    datacurcount=5;                                        //selects position first of char array
                    digitBlinkData=EarthLeakage1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;
                case 1:
                    WriteCommandLCD(0xC5);                                 //cursor on first position
                    datacurcount=6;                                        //selects position first of char array
                    digitBlinkData=EarthLeakage1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;
                case 2:
                    WriteCommandLCD(0xCE);                                 //cursor on first position
                    datacurcount=7;                                        //selects position first of char array
                    digitBlinkData=EarthLeakage1[datacurcount];                 //copies position first data of char array to digitBlinkData
                   break;
                case 3:
                    WriteCommandLCD(0xCF);                                 //cursor on first position
                    datacurcount=16;                                        //selects position first of char array
                    digitBlinkData=EarthLeakage1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;
                default:
                    WriteCommandLCD(0xC4);                                 //cursor on first position
                    datacurcount=5;                                        //selects position first of char array
                    digitBlinkData=EarthLeakage1[datacurcount];                 //copies position first data of char array to digitBlinkData
                    break;
                }
            }
        }
        if(incKey==0 && subFactDisp==1 ){    //sense increment key for display 1
            //stopKeySense=1;
            tempData=inUnderVtg1[datacurcount];          //copying current string character value
            tempData++;                               //Incrementing current character value by 1
            digitBlinkData=tempData;                  //updating blinking cursor value with current character value
            maxCount();                               //setting maximum count to 9.
            }


        if(decKey==0 && subFactDisp==1){     //sense decrement key for display 1
            //stopKeySense=1;
            tempData=inUnderVtg1[datacurcount];           //copying current string character value
            tempData--;                                //Decrementing current character value by 1
            digitBlinkData=tempData;                   //updating blinking cursor value with current character value
            minCount();                                //setting minimum count to 0.
            }


        if(subFactDisp==1){                  //digit blink function for display one
            tempBlinker=20;                            //character blank data
            inUnderVtg1[datacurcount]=tempBlinker;        //updating blank character value to the stored string character value
            InUnderVtg();                          //calling output display routine
            DELAY_US(200000);                          //Delay for 200 milliseconds
            tempBlinker=digitBlinkData;                //copying actual character value for blinking purpose
            inUnderVtg1[datacurcount]=tempBlinker;        //updating current character value to the stored string character value
            InUnderVtg();                        //calling output display routine
            DELAY_US(100000);                          //Delay for 100 milliseconds
            }
        if(incKey==0 && subFactDisp==2 ){    //sense increment key for display 1
            //stopKeySense=1;
            tempData=inOverVtg1[datacurcount];          //copying current string character value
            tempData++;                               //Incrementing current character value by 1
            digitBlinkData=tempData;                  //updating blinking cursor value with current character value
            maxCount();                               //setting maximum count to 9.
            }


        if(decKey==0 && subFactDisp==2){     //sense decrement key for display 1
            //stopKeySense=1;
            tempData=inOverVtg1[datacurcount];           //copying current string character value
            tempData--;                                //Decrementing current character value by 1
            digitBlinkData=tempData;                   //updating blinking cursor value with current character value
            minCount();                                //setting minimum count to 0.
            }


        if(subFactDisp==2){                  //digit blink function for display one
            tempBlinker=20;                            //character blank data
            inOverVtg1[datacurcount]=tempBlinker;        //updating blank character value to the stored string character value
            InOverVtg();                          //calling output display routine
            DELAY_US(200000);                          //Delay for 200 milliseconds
            tempBlinker=digitBlinkData;                //copying actual character value for blinking purpose
            inOverVtg1[datacurcount]=tempBlinker;        //updating current character value to the stored string character value
            InOverVtg();                       //calling output display routine
            DELAY_US(100000);                          //Delay for 100 milliseconds
            }
        if(incKey==0 && subFactDisp==3 ){    //sense increment key for display 1
          //stopKeySense=1;
            tempData=OutOverVtg1[datacurcount];          //copying current string character value
            tempData++;                               //Incrementing current character value by 1
            digitBlinkData=tempData;                  //updating blinking cursor value with current character value
            maxCount();                               //setting maximum count to 9.
            }
        if(decKey==0 && subFactDisp==3){     //sense decrement key for display 1
          //stopKeySense=1;
            tempData=OutOverVtg1[datacurcount];           //copying current string character value
            tempData--;                                //Decrementing current character value by 1
            digitBlinkData=tempData;                   //updating blinking cursor value with current character value
            minCount();                                //setting minimum count to 0.
            }
        if(subFactDisp==3){                  //digit blink function for display one
            tempBlinker=20;                            //character blank data
            OutOverVtg1[datacurcount]=tempBlinker;        //updating blank character value to the stored string character value
            outOverVtg();                         //calling output display routine
            DELAY_US(200000);                          //Delay for 200 milliseconds
            tempBlinker=digitBlinkData;                //copying actual character value for blinking purpose
            OutOverVtg1[datacurcount]=tempBlinker;        //updating current character value to the stored string character value
            outOverVtg();                       //calling output display routine
            DELAY_US(100000);                          //Delay for 100 milliseconds
            }
        if(incKey==0 && subFactDisp==4 ){    //sense increment key for display 1
            //stopKeySense=1;
            tempData=OutOverAmp1[datacurcount];          //copying current string character value
            tempData++;                               //Incrementing current character value by 1
            digitBlinkData=tempData;                  //updating blinking cursor value with current character value
            maxCount();                               //setting maximum count to 9.
            }
        if(decKey==0 && subFactDisp==4){     //sense decrement key for display 1
                  //stopKeySense=1;
            tempData=OutOverAmp1[datacurcount];           //copying current string character value
            tempData--;                                //Decrementing current character value by 1
            digitBlinkData=tempData;                   //updating blinking cursor value with current character value
            minCount();                                //setting minimum count to 0.
            }
        if(subFactDisp==4){                  //digit blink function for display one
             tempBlinker=20;                            //character blank data
             OutOverAmp1[datacurcount]=tempBlinker;        //updating blank character value to the stored string character value
             outOverAmp();                        //calling output display routine
             DELAY_US(200000);                          //Delay for 200 milliseconds
             tempBlinker=digitBlinkData;                //copying actual character value for blinking purpose
             OutOverAmp1[datacurcount]=tempBlinker;        //updating current character value to the stored string character value
             outOverAmp();                     //calling output display routine
             DELAY_US(100000);                          //Delay for 100 milliseconds
             }
         if(incKey==0 && subFactDisp==5){    //sense increment key for display 1
                          //stopKeySense=1;
             tempData=shortCktvtg1[datacurcount];          //copying current string character value
             tempData++;                               //Incrementing current character value by 1
             digitBlinkData=tempData;                  //updating blinking cursor value with current character value
             maxCount();                               //setting maximum count to 9.
             }
         if(decKey==0 && subFactDisp==5){     //sense decrement key for display 1
                          //stopKeySense=1;
             tempData=shortCktvtg1[datacurcount];           //copying current string character value
             tempData--;                                //Decrementing current character value by 1
             digitBlinkData=tempData;                   //updating blinking cursor value with current character value
             minCount();                                //setting minimum count to 0.
             }
          if(subFactDisp==5){                  //digit blink function for display one
              tempBlinker=20;                            //character blank data
              shortCktvtg1[datacurcount]=tempBlinker;        //updating blank character value to the stored string character value
              shortCkt();                        //calling output display routine
              DELAY_US(200000);                          //Delay for 200 milliseconds
              tempBlinker=digitBlinkData;                //copying actual character value for blinking purpose
              shortCktvtg1[datacurcount]=tempBlinker;        //updating current character value to the stored string character value
              shortCkt();                    //calling output display routine
              DELAY_US(100000);                          //Delay for 100 milliseconds
             }
          if(incKey==0 && subFactDisp==6){    //sense increment key for display 1
                                                  //stopKeySense=1;
              tempData=TxTemp1[datacurcount];          //copying current string character value
              tempData++;                               //Incrementing current character value by 1
              digitBlinkData=tempData;                  //updating blinking cursor value with current character value
              maxCount();                               //setting maximum count to 9.
             }
           if(decKey==0 && subFactDisp==6){     //sense decrement key for display 1
                                                  //stopKeySense=1;
              tempData=TxTemp1[datacurcount];           //copying current string character value
              tempData--;                                //Decrementing current character value by 1
              digitBlinkData=tempData;                   //updating blinking cursor value with current character value
              minCount();                                //setting minimum count to 0.
             }
            if(subFactDisp==6){                  //digit blink function for display one
              tempBlinker=20;                            //character blank data
              TxTemp1[datacurcount]=tempBlinker;        //updating blank character value to the stored string character value
              TransTemp();                     //calling output display routine
              DELAY_US(200000);                          //Delay for 200 milliseconds
              tempBlinker=digitBlinkData;                //copying actual character value for blinking purpose
              TxTemp1[datacurcount]=tempBlinker;        //updating current character value to the stored string character value
              TransTemp();                   //calling output display routine
              DELAY_US(100000);                          //Delay for 100 milliseconds
              }
            if(incKey==0 && subFactDisp==7){    //sense increment key for display 1
                                                                                                  //stopKeySense=1;
              tempData=TempHsDevice1[datacurcount];          //copying current string character value
              tempData++;                               //Incrementing current character value by 1
              digitBlinkData=tempData;                  //updating blinking cursor value with current character value
              maxCount();                               //setting maximum count to 9.
              }
             if(decKey==0 && subFactDisp==7){     //sense decrement key for display 1
                                                                                                  //stopKeySense=1;
               tempData=TempHsDevice1[datacurcount];           //copying current string character value
               tempData--;                                //Decrementing current character value by 1
               digitBlinkData=tempData;                   //updating blinking cursor value with current character value
               minCount();                                //setting minimum count to 0.
              }
             if(subFactDisp==7){                  //digit blink function for display one
               tempBlinker=20;                            //character blank data
               TempHsDevice1[datacurcount]=tempBlinker;        //updating blank character value to the stored string character value
               HsTemp();                   //calling output display routine
               DELAY_US(200000);                          //Delay for 200 milliseconds
               tempBlinker=digitBlinkData;                //copying actual character value for blinking purpose
               TempHsDevice1[datacurcount]=tempBlinker;        //updating current character value to the stored string character value
               HsTemp();                   //calling output display routine
               DELAY_US(100000);                          //Delay for 100 milliseconds
              }
             if(incKey==0 && subFactDisp==8 ){    //sense increment key for display 1
                                                                                                                  //stopKeySense=1;
               tempData=EarthLeakage1[datacurcount];          //copying current string character value
               tempData++;                               //Incrementing current character value by 1
               digitBlinkData=tempData;                  //updating blinking cursor value with current character value
               maxCount();                               //setting maximum count to 9.
              }
             if(decKey==0 && subFactDisp==8){     //sense decrement key for display 1
                                                                                                                  //stopKeySense=1;
               tempData=EarthLeakage1[datacurcount];           //copying current string character value
               tempData--;                                //Decrementing current character value by 1
               digitBlinkData=tempData;                   //updating blinking cursor value with current character value
               minCount();                                //setting minimum count to 0.
              }
             if(subFactDisp==8){                  //digit blink function for display one
               tempBlinker=20;                            //character blank data
               EarthLeakage1[datacurcount]=tempBlinker;        //updating blank character value to the stored string character value
               earthLeakage();                    //calling output display routine
               DELAY_US(200000);                          //Delay for 200 milliseconds
               tempBlinker=digitBlinkData;                //copying actual character value for blinking purpose
               EarthLeakage1[datacurcount]=tempBlinker;        //updating current character value to the stored string character value
               earthLeakage();                 //calling output display routine
               DELAY_US(100000);                          //Delay for 100 milliseconds
              }

    }
    //*************************************************************************************************************************************************************//
    //*******************************************************Factory Setting - 2 *********************************************************************************//

    if(doorstatus==1 && innerdisp==1||innerdisp==2||innerdisp==3||innerdisp==4 || sbtwo==1){              //Enables shift key only when sub displays are selected
    if(shiftKey == 0){                                                       //cursor shift function
        stopKeySense=1;
        curcount++;                                                          //Increments cursor pointer
        if(innerdisp==1){                                                    //Shift key operation for Output voltage setting
            if(curcount>3){                            //cursor jumps to position first after shift key is pressed at fourth position
                curcount=0;
            }
            switch(curcount){                                          //Cursor position selection for output voltage setting display
            case 0:
                WriteCommandLCD(0xC5);                                 //cursor on first position
                datacurcount=0;                                        //selects position first of char array
                digitBlinkData=opoutvtg[datacurcount];                 //copies position first data of char array to digitBlinkData
                break;
            case 1:
                WriteCommandLCD(0xC6);                                 //cursor on second position
                datacurcount=1;                                        //selects position second of char array
                digitBlinkData=opoutvtg[datacurcount];                 //copies position second data of char array to digitBlinkData
                break;
            case 2:
                WriteCommandLCD(0xC7);                                 //cursor on third position
                datacurcount=3;                                        //selects position third of char array
                digitBlinkData=opoutvtg[datacurcount];                 //copies position third data of char array to digitBlinkData
                break;
            case 3:
                WriteCommandLCD(0xC8);                                 //cursor on fourth position
                datacurcount=4;                                        //selects position fourth of char array
                digitBlinkData=opoutvtg[datacurcount];                 //copies position fourth data of char array to digitBlinkData
                break;
            default:
                WriteCommandLCD(0xC5);                                 //cursor on position first by default
                datacurcount=0;                                        //selects position first of char array by default
                digitBlinkData=opoutvtg[datacurcount];                 //copies position first data of char array to digitBlinkData
                break;
            }
        }

        if(innerdisp==2){                                             //shift key operation for battery current setting
            if(curcount>3){                                     //cursor jumps to position one if it is incremented on third position
                curcount=0;
            }
            switch(curcount){                                         //Cursor position selection for battery current setting display
            case 0:
                WriteCommandLCD(0xC5);                                //cursor position at first position
                datacurcount=0;                                       //selects position first of char array
                digitBlinkData=opoutamp[datacurcount];              //copies position first data of char array to digitBlinkData
                break;
            case 1:
                WriteCommandLCD(0xC6);                                //cursor position at second position
                datacurcount=1;                                       //selects position second of char array
                digitBlinkData=opoutamp[datacurcount];              //copies position second data of char array to digitBlinkData
                break;
            case 2:
                WriteCommandLCD(0xC8);                                //cursor position at third position
                datacurcount=3;                                       //selects position third of char array
                digitBlinkData=opoutamp[datacurcount];              //copies position third data of char array to digitBlinkData
                break;
            case 3:
                WriteCommandLCD(0xC9);                                //cursor position at third position
                datacurcount=4;                                       //selects position third of char array
                digitBlinkData=opoutamp[datacurcount];              //copies position third data of char array to digitBlinkData
                break;
            default:
                WriteCommandLCD(0xC5);                                //cursor on position first by default
                datacurcount=0;                                       //selects position first of char array by default
                digitBlinkData=opoutamp[datacurcount];              //copies position first data of char array to digitBlinkData
                break;
            }
        }
        if(innerdisp==3){                                             //shift key operation for battery current setting
            if(curcount>2){                                     //cursor jumps to position one if it is incremented on third position
                curcount=0;
            }
            switch(curcount){                                         //Cursor position selection for battery current setting display
            case 0:
                WriteCommandLCD(0xC5);                                //cursor position at first position
                datacurcount=0;                                       //selects position first of char array
                digitBlinkData=batcurrent[datacurcount];              //copies position first data of char array to digitBlinkData
                break;
            case 1:
                WriteCommandLCD(0xC6);                                //cursor position at second position
                datacurcount=1;                                       //selects position second of char array
                digitBlinkData=batcurrent[datacurcount];              //copies position second data of char array to digitBlinkData
                break;
             case 2:
                WriteCommandLCD(0xC8);                                //cursor position at third position
                datacurcount=3;                                       //selects position third of char array
                digitBlinkData=batcurrent[datacurcount];              //copies position third data of char array to digitBlinkData
                break;
             default:
                WriteCommandLCD(0xC5);                                //cursor on position first by default
                datacurcount=0;                                       //selects position first of char array by default
                digitBlinkData=batcurrent[datacurcount];              //copies position first data of char array to digitBlinkData
                break;
            }
        }

        if(subinnerdispone==1){   //shift key operation for Battery health check
            if(curcount>5){
                curcount=0;          //cursor initializer
            }
            switch(curcount){
            case 0:
                WriteCommandLCD(0xC5);                                //cursor position first of time
                datacurcount=0;                                       //cursor pointer updater
                digitBlinkData=logDatabyDate1[datacurcount];             //digit blinker
                break;
            case 1:
                WriteCommandLCD(0xC6);                                //cursor position second of time
                datacurcount=1;                                       //cursor pointer updater
                digitBlinkData=logDatabyDate1[datacurcount];             //digit blinker
                break;
            case 2:
                WriteCommandLCD(0xC8);                                //cursor position third of time
                datacurcount=3;                                       //cursor pointer updater
                digitBlinkData=logDatabyDate1[datacurcount];             //digit blinker
                break;
            case 3:
                WriteCommandLCD(0xC9);                                //cursor position fourth of time
                datacurcount=4;                                       //cursor pointer updater
                digitBlinkData=logDatabyDate1[datacurcount];             //digit blinker
                break;
            case 4:
                WriteCommandLCD(0xCB);                                //cursor position fifth of time
                datacurcount=6;                                       //cursor pointer updater
                digitBlinkData=logDatabyDate1[datacurcount];             //digit blinker
                break;
            case 5:
                WriteCommandLCD(0xCC);                                //cursor position sixth of time
                datacurcount=7;                                       //cursor pointer updater
                digitBlinkData=logDatabyDate1[datacurcount];             //digit blinker
                break;
            default:
                WriteCommandLCD(0xC5);  //cursor position default
                datacurcount=8;      //cursor pointer updater
                digitBlinkData=logDatabyDate1[datacurcount];     //digit blinker
                break;
            }
        }

        if(subinnerdisp==1){                                             //shift key operation for RTC data time setting
            if(curcount>11){                                          //cursor jumps to position one if it is incremented on position eleventh
                curcount=0;                                           //cursor to default start position
            }
            switch(curcount){
            case 0:
                WriteCommandLCD(0xC5);                                //cursor position first of time
                datacurcount=0;                                       //cursor pointer updater
                digitBlinkData=rtcdatatime[datacurcount];             //digit blinker
                break;
            case 1:
                WriteCommandLCD(0xC6);                                //cursor position second of time
                datacurcount=1;                                       //cursor pointer updater
                digitBlinkData=rtcdatatime[datacurcount];             //digit blinker
                break;
            case 2:
                WriteCommandLCD(0xC8);                                //cursor position third of time
                datacurcount=3;                                       //cursor pointer updater
                digitBlinkData=rtcdatatime[datacurcount];             //digit blinker
                break;
            case 3:
                WriteCommandLCD(0xC9);                                //cursor position fourth of time
                datacurcount=4;                                       //cursor pointer updater
                digitBlinkData=rtcdatatime[datacurcount];             //digit blinker
                break;
            case 4:
                WriteCommandLCD(0xCB);                                //cursor position fifth of time
                datacurcount=6;                                       //cursor pointer updater
                digitBlinkData=rtcdatatime[datacurcount];             //digit blinker
                break;
             case 5:
                WriteCommandLCD(0xCC);                                //cursor position sixth of time
                datacurcount=7;                                       //cursor pointer updater
                digitBlinkData=rtcdatatime[datacurcount];             //digit blinker
                break;
             case 6:
                WriteCommandLCD(0x99);                                //cursor position first for date
                datacurcount=0;                                       //cursor pointer updater
                digitBlinkData=rtcdatadate[datacurcount];             //digit blinker
                break;
             case 7:
                WriteCommandLCD(0x9A);                                //cursor position second for date
                datacurcount=1;                                       //cursor pointer updater
                digitBlinkData=rtcdatadate[datacurcount];             //digit blinker
                break;
             case 8:
                WriteCommandLCD(0x9C);                                   //cursor position third for date
                datacurcount=3;                                      //cursor pointer updater
                digitBlinkData=rtcdatadate[datacurcount];                //digit blinker
                break;
             case 9:
                WriteCommandLCD(0x9D);                                //cursor position fourth for date
                datacurcount=4;                                      //cursor pointer updater
                digitBlinkData=rtcdatadate[datacurcount];          //digit blinker
                break;
             case 10:
                WriteCommandLCD(0x9F);                             //cursor position fifth for date
                datacurcount=6;                               //cursor pointer updater
                digitBlinkData=rtcdatadate[datacurcount];        //digit blinker
                break;
             case 11:
                WriteCommandLCD(0xA0); //cursor position sixth for date
                datacurcount=7; //cursor pointer updater
                digitBlinkData=rtcdatadate[datacurcount];  //digit blinker
                break;
             default:
                WriteCommandLCD(0xC5); //cursor position default
                datacurcount=0; //cursor pointer updater
                digitBlinkData=rtcdatatime[datacurcount]; //digit blinker
                break;
            }
        }

        if(subinnerdisp==2){   //shift key operation for Battery health check
            if(curcount>3){
                curcount=0;          //cursor initializer
            }
            switch(curcount){
            case 0:
                WriteCommandLCD(0xC8);          //cursor position at first
                datacurcount=8;                 //cursor pointer updater
                digitBlinkData=batHealthTime[datacurcount]; //digit blinker
                break;
            case 1:
                WriteCommandLCD(0xC9);  //cursor position at second
                datacurcount=9;    //cursor pointer updater
                digitBlinkData=batHealthTime[datacurcount];  //digit blinker
                break;
            case 2:
                WriteCommandLCD(0xCB); //cursor position at third
                datacurcount=11; //cursor pointer updater
                digitBlinkData=batHealthTime[datacurcount]; //digit blinker
                break;
            case 3:
                WriteCommandLCD(0xCC); //cursor position at fourth
                datacurcount=12; //cursor pointer updater
                digitBlinkData=batHealthTime[datacurcount]; //digit blinker
                break;
            default:
                WriteCommandLCD(0xC8);  //cursor position default
                datacurcount=8;      //cursor pointer updater
                digitBlinkData=batHealthTime[datacurcount];     //digit blinker
                break;
            }
        }

    }

    if(incKey==0 && sbone==1 && innerdisp==1 && stopKeySense==0){    //sense increment key for display 1
        stopKeySense=1;
        tempData=opoutvtg[datacurcount];          //copying current string character value
        tempData++;                               //Incrementing current character value by 1
        digitBlinkData=tempData;                  //updating blinking cursor value with current character value
        maxCount();                               //setting maximum count to 9.
    }


    if(decKey==0 && sbone==1 && innerdisp==1 && stopKeySense==0){     //sense decrement key for display 1
        stopKeySense=1;
        tempData=opoutvtg[datacurcount];           //copying current string character value
        tempData--;                                //Decrementing current character value by 1
        digitBlinkData=tempData;                   //updating blinking cursor value with current character value
        minCount();                                //setting minimum count to 0.
    }


    if(sbone==1 && innerdisp==1){                  //digit blink function for display one
        tempBlinker=20;                            //character blank data
        opoutvtg[datacurcount]=tempBlinker;        //updating blank character value to the stored string character value
        outputVoltage();                           //calling output display routine
        DELAY_US(200000);                          //Delay for 200 milliseconds
        tempBlinker=digitBlinkData;                //copying actual character value for blinking purpose
        opoutvtg[datacurcount]=tempBlinker;        //updating current character value to the stored string character value
        outputVoltage();                           //calling output display routine
        DELAY_US(100000);                          //Delay for 100 milliseconds
    }
    if(incKey==0 && sbone==1 && innerdisp==2 && stopKeySense==0){    //sense increment key for display 1
            stopKeySense=1;
            tempData=opoutamp[datacurcount];          //copying current string character value
            tempData++;                               //Incrementing current character value by 1
            digitBlinkData=tempData;                  //updating blinking cursor value with current character value
            maxCount();                               //setting maximum count to 9.
        }


        if(decKey==0 && sbone==1 && innerdisp==2 && stopKeySense==0){     //sense decrement key for display 1
            stopKeySense=1;
            tempData=opoutamp[datacurcount];           //copying current string character value
            tempData--;                                //Decrementing current character value by 1
            digitBlinkData=tempData;                   //updating blinking cursor value with current character value
            minCount();                                //setting minimum count to 0.
        }


        if(sbone==1 && innerdisp==2){                  //digit blink function for display one
            tempBlinker=20;                            //character blank data
            opoutamp[datacurcount]=tempBlinker;        //updating blank character value to the stored string character value
            outputCurrent();                           //calling output display routine
            DELAY_US(200000);                          //Delay for 200 milliseconds
            tempBlinker=digitBlinkData;                //copying actual character value for blinking purpose
            opoutamp[datacurcount]=tempBlinker;        //updating current character value to the stored string character value
            outputCurrent();                           //calling output display routine
            DELAY_US(100000);                          //Delay for 100 milliseconds
        }

    if(incKey==0 && sbone==1 && innerdisp==3 && stopKeySense==0){     //sensing Incrementing key for display two
        stopKeySense=1;
        tempData=batcurrent[datacurcount];         //copying current string character value
        tempData++;                                //Incrementing current cursor value by 1
        maxCount();                                //setting maximum count to 9
        digitBlinkData=tempData;                   //updating blinking data with current cursor value
    }
    if(decKey==0 && sbone==1 && innerdisp==3 && stopKeySense==0){     //sensing decrementing key for display two
        stopKeySense=1;
        tempData=batcurrent[datacurcount];         //copying current string character value
        tempData--;                                //decrementing current character value by one
        digitBlinkData=tempData;                   //updating blinking data with current cursor value
        minCount();                                //setting minimum count to 0
    }
    if(sbone==1 && innerdisp==3){                  //digit blink function for display two
        tempBlinker=20;                            //character blank data
        batcurrent[datacurcount]=tempBlinker;      //updating blank character value to the stored string character value
        batteryCurrent();                          //calling battery current  display routine
        DELAY_US(200000);                          //Delay for 200 milliseconds
        tempBlinker=digitBlinkData;                //copying actual character value for blinking purpose
        batcurrent[datacurcount]=tempBlinker;      //updating current character value to the stored string character value
        batteryCurrent();                          //calling battery current display routine
        DELAY_US(100000);                          //Delay for 100 milliseconds
    }
    if(incKey==0 && sbone==1 && subinnerdisp==1 && stopKeySense==0){     //Sensing incrementing key for display three
        stopKeySense=1;
        if(curcount<=5){                           //tracking cursor position for rtc time value updating
        tempData=rtcdatatime[datacurcount];        //copying current character value
        tempData++;                                //Incrementing character value by one
        maxCount();                                //setting maximum count to 9
        digitBlinkData=tempData;                   //updating current cursor value
        }else if(curcount>5 && curcount<=11){      //tracking cursor position for rtc date value updating
            tempData=rtcdatadate[datacurcount];    //copying current character value
            tempData++;                            //Incrementing current cursor value by one
            maxCount();                            //setting maximum count to 9
            digitBlinkData=tempData;               //updating current cursor value
        }
    }
    if(decKey==0 && sbone==1 && subinnerdisp==1 && stopKeySense==0){     //sensing decrementing key for display three
        stopKeySense=1;
        if(curcount<=5){                           //tracking cursor position for rtc time updating
        tempData=rtcdatatime[datacurcount];        //copying current character value
        tempData--;                                //Decrementing character value by one
        minCount();                                //setting minimum count to 0
        digitBlinkData=tempData;                   //updating current cursor value
        }else if(curcount>5 && curcount<=11){      //tracking cursor position for rtc date updating
            tempData=rtcdatadate[datacurcount];    //copying current character value
            tempData--;                            //Decrementing current cursor value by one
            minCount();                            //setting minimum count to 0
            digitBlinkData=tempData;               //updating current cursor value
        }
    }
    if(sbone==1 && subinnerdisp==1){                  //digit blinker function
        if(curcount<=5){                           //tracking cursor position for rtc time value updating
        tempBlinker=20;                            //character blank data
        rtcdatatime[datacurcount]=tempBlinker;     //updating blank character value to the stored string character value
        clockRtc();                                //calling RTC display routine
        DELAY_US(200000);                          //Delay for 200 milliseconds
        tempBlinker=digitBlinkData;                //copying actual character value for blinking purpose
        rtcdatatime[datacurcount]=tempBlinker;     //updating current character value to the stored string character value
        clockRtc();                                //calling rtc display routine
        DELAY_US(100000);                          //Delay for 100 milliseconds
        }else if(curcount>5 && curcount<=11){      //tracking cursor position for rtc date value updating
            tempBlinker=20;                        //character blank data
            rtcdatadate[datacurcount]=tempBlinker; //updating blank character value to the stored string character value
            clockRtc();                            //calling RTC display routine
            DELAY_US(200000);                      //Delay for 200 milliseconds
            tempBlinker=digitBlinkData;            //copying actual character value for blinking purpose
            rtcdatadate[datacurcount]=tempBlinker; //updating current  character value for blinking purpose
            clockRtc();                            //calling RTC display routine
            DELAY_US(100000);                      //Delay for 100 seconds
        }
    }
    if(incKey==0 && sbone==1 && subinnerdisp==2 && stopKeySense==0){     //sensing incrementing key for display four
        stopKeySense=1;
        if(datacurcount==0){                       //cursor position initializer for display 4
            datacurcount=8;                        //initial position of the cursor
        }
        tempData=batHealthTime[datacurcount];      //copying current character value of string
        tempData++;                                //Incrementing character data by one
        digitBlinkData=tempData;                   //sending character value for blinking purpose
        maxCount();                                //setting maximum value to 9
    }
    if(decKey==0 && sbone==1 && subinnerdisp==2 && stopKeySense==0){     //sensing decrementing key for display four
        stopKeySense=1;
        if(datacurcount==0){                       //cursor position initializer for display 4
            datacurcount=8;                        //initial position of the cursor
        }
        tempData=batHealthTime[datacurcount];      //copying current character value of string
        tempData--;                                //Decrementing character data by one
        digitBlinkData=tempData;                   //sending character value for blinking purpose
        minCount();                                //setting minimum value to 0
    }
    if(sbone==1 && subinnerdisp==2){
        if(datacurcount==0){                       //cursor position initializer for display 4
            datacurcount=8;                        //initial position of the cursor
        }
        tempBlinker=20;                            //character blank data
        batHealthTime[datacurcount]=tempBlinker;   //updating character value to the stored string character value
        batteryHealth();                           //calling battery health display routine
        DELAY_US(200000);                          //Delay 200 milliseconds
        tempBlinker=digitBlinkData;                //updating
        batHealthTime[datacurcount]=tempBlinker;
        batteryHealth();
        DELAY_US(100000);
    }


    if(incKey==0 && sbtwo==1 && subinnerdispone==1 ){     //sensing Incrementing key for display two
        //stopKeySense=1;
        tempData=logDatabyDate1[datacurcount];         //copying current string character value
        tempData++;                                //Incrementing current cursor value by 1
        maxCount();                                //setting maximum count to 9
        digitBlinkData=tempData;                   //updating blinking data with current cursor value
    }
    if(decKey==0 && sbtwo==1 && subinnerdispone==1){     //sensing decrementing key for display two
        //stopKeySense=1;
        tempData=logDatabyDate1[datacurcount];         //copying current string character value
        tempData--;                                //decrementing current character value by one
        digitBlinkData=tempData;                   //updating blinking data with current cursor value
        minCount();                                //setting minimum count to 0
    }
    if(sbtwo==1 && subinnerdispone==1){                  //digit blink function for display two
        tempBlinker=20;                            //character blank data
        logDatabyDate1[datacurcount]=tempBlinker;      //updating blank character value to the stored string character value
        LogDatabyDate();                          //calling battery current  display routine
        DELAY_US(200000);                          //Delay for 200 milliseconds
        tempBlinker=digitBlinkData;                //copying actual character value for blinking purpose
        logDatabyDate1[datacurcount]=tempBlinker;      //updating current character value to the stored string character value
        LogDatabyDate();                        //calling battery current display routine
        DELAY_US(100000);                          //Delay for 100 milliseconds
    }

    if(updatertc==1){
        finalsecvalue=(int)((rtcdatatime[6] - '0') << 4) | (rtcdatatime[7] - '0');
        rtc_write(0x00,finalsecvalue);
        DELAY_US(1000);
        finalminvalue=(int)((rtcdatatime[3] - '0') << 4) | (rtcdatatime[4] - '0');
        rtc_write(0x01,finalminvalue);
        DELAY_US(1000);
        finalhourvalue=(int)((rtcdatatime[0] - '0') << 4) | (rtcdatatime[1] - '0');
        rtc_write(0x02,finalhourvalue);
        DELAY_US(1000);
        finaldatevalue=(int)((rtcdatadate[0] - '0') << 4) | (rtcdatadate[1] - '0');
        rtc_write(0x04,finaldatevalue);
        DELAY_US(1000);
        finalmonthvalue=(int)((rtcdatadate[3] - '0') << 4) | (rtcdatadate[4] - '0');
        rtc_write(0x05,finalmonthvalue);
        DELAY_US(1000);
        finalyearvalue=(int)((rtcdatadate[6] - '0') << 4) | (rtcdatadate[7] - '0');
        rtc_write(0x06,finalyearvalue);
        DELAY_US(7000);
        updatertc=0;
        PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;
    }
    if(incKey==0 && fltDisp==1 && subinnerdispone==2 && sbtwo==1){
        DELAY_US(500000);
        rd_ee=1;
    }
    if(doorstatus==1 && fltDisp==1 && subinnerdispone==2 && sbtwo==1){
        DELAY_US(250000);
        FaultScreen();
    }
    }

    //************************************************************************************************************************************************************//
    if(doorstatus==1 && factDispDoor==0){
    if(enterKey == 0 && sbone==1 && subinnerdisp==1){
        updatertc=1;
        DELAY_US(250000);
        //updatertc=0;
        setTime();
        subinnerdisp=0;
        curcount=0;
        datacurcount=0;
    }
    if(enterKey == 0 && keyValue==1 && sbone==0 && sbtwo==0 && sbthree==0 && doorstatus==1 && stopKeySense==0 ){
        stopKeySense=1;
        debouncestart=1;
        debounce();
        if(enterKey==0 && open==1){
            fieldSetting();
            sbone=1;
            sbtwo=0;
        }
        oldkeyval=keyValue;
    }
    if(enterKey == 0 && keyValue==2 && sbone==0 && sbtwo==0 && sbthree==0 && doorstatus==1 && stopKeySense==0 ){
        stopKeySense=1;
        debouncestart=1;
        debounce();
        if(enterKey==0 && open==1){
            LogData();
            sbtwo=1;
            subdispKeyVal=1;
            sbone=0;
        }
        oldkeyval=keyValue;
    }
    //************************CAUTION: WORK IN PROGRESS****************************************************************************************************
    /*if(enterKey == 0 && sbone==0 && sbtwo==0 && sbthree==0 && doorstatus==1 && stopKeySense==0 ){
        if(keyValue==1){
            stopKeySense=1;
            debouncestart=1;
            debounce();
            if(enterKey==0 && open==1){
                fieldSetting();
                sbone=1;
                sbtwo=0;
                maindispstatus=1;
            }
            oldkeyval=keyValue;
        }else{
            if(keyValue==2){
                stopKeySense=1;
                debouncestart=1;
                debounce();
                if(enterKey==0 && open==1){
                    LogData();
                    sbtwo=1;
                    subdispKeyVal=1;
                    sbone=0;
                    maindispstatus=2;
                }
                oldkeyval=keyValue;

            }
        }
    }*/

    //^^^^^^^^^^^^^^^^^^^^^^^^


    if(enterKey == 0 && sbone==1 && keyValue==1 && j==0 && doorstatus==1 && stopKeySense==0){
        scanKey=2;
        debouncestart=1;
        stopKeySense=1;
        debounce();
        if(enterKey==0 && open==1){
            digitBlinkData=opoutvtg[0];
            outputVoltage();
            innerdisp=1;
        }
        oldkeyval=keyValue;
    }

    if(enterKey == 0 && sbone==1 && keyValue==2 && doorstatus==1 && stopKeySense==0){
            scanKey=2;
            stopKeySense=1;
            debouncestart=1;
            debounce();
            if(enterKey==0 && open==1){
                digitBlinkData=opoutamp[0];
                outputCurrent();
                innerdisp=2;
            }
            oldkeyval=keyValue;
        }
    if(enterKey == 0 && sbone==1 && keyValue==3 && doorstatus==1 && stopKeySense==0){
        scanKey=2;
        stopKeySense=1;
        debouncestart=1;
        debounce();
        if(enterKey==0 && open==1){
            digitBlinkData=batcurrent[0];
            batteryCurrent();
            innerdisp=3;
        }
        oldkeyval=keyValue;
    }

    while(enterKey == 0 && sbone==1 && keyValue==4 && doorstatus==1 && stopKeySense==0){
        scanKey=2;
        stopKeySense=1;
        debouncestart=1;
        debounce();
        if(enterKey==0 && open==1){
            setTime();
            innerdisp=4;
            subdispKeyVal=1;
        }
        oldkeyval=keyValue;
    }

    //*******************************CAUTION: WORK IN PROGRESS***************************
    /*if(enterKey == 0 && sbone==1 && doorstatus==1 && stopKeySense==0){
        if(keyValue==1){
            scanKey=2;
            debouncestart=1;
            stopKeySense=1;
            debounce();
            if(enterKey==0 && open==1){
                digitBlinkData=opoutvtg[0];
                outputVoltage();
                innerdisp=1;
            }
            oldkeyval=keyValue;
        }else{
            if(keyValue==2){
                scanKey=2;
                stopKeySense=1;
                debouncestart=1;
                debounce();
                if(enterKey==0 && open==1){
                    digitBlinkData=opoutamp[0];
                    outputCurrent();
                    innerdisp=2;
                }
                oldkeyval=keyValue;

            }else{
                if(keyValue==3){
                    scanKey=2;
                    stopKeySense=1;
                    debouncestart=1;
                    debounce();
                    if(enterKey==0 && open==1){
                        digitBlinkData=batcurrent[0];
                        batteryCurrent();
                        innerdisp=3;
                    }
                    oldkeyval=keyValue;

                }else{
                    if(keyValue==4){
                        scanKey=2;
                        stopKeySense=1;
                        debouncestart=1;
                        debounce();
                        if(enterKey==0 && open==1){
                            setTime();
                            innerdisp=4;
                            subdispKeyVal=1;
                        }
                        oldkeyval=keyValue;

                    }
                }
            }

        }

    }*/

    //^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    if(innerdisp==4 || sbtwo==1 && subinnerdispone==0){

        if(incKey == 0  && innerdisp==4 || incKey == 0  && sbtwo==1){                      //Increment key
            DELAY_US(200000);
            subdispKeyVal+=1;
        }else if(decKey == 0  &&  innerdisp==4 || decKey == 0  &&  sbtwo==1){               //Decrement key
            DELAY_US(200000);
            subdispKeyVal-=1;
        }
        if(subdispKeyVal<0){                      //cursor jumps to position first after increment key pressed on fourth position
            subdispKeyVal=2;
        }else if(subdispKeyVal==3){               //cursor jumps to position fourth after decrement key pressed on first position
            subdispKeyVal=0;
        }
        switch(subdispKeyVal){                    //selects cursor position
        case 1:
            WriteCommandLCD(0x80);           //Line One position
            break;
        case 2:
            WriteCommandLCD(0xC0);          //Line Two position
            break;
        default:
            WriteCommandLCD(0x80);        //By default cursor position is Line One
            break;
        }
    }

    if(sbtwo==1 && subinnerdispone==2 && fltDisp==0){
            if(incKey == 0  && sbtwo==1  && subinnerdispone==2){                      //Increment key
                DELAY_US(200000);
                fltdispslk+=1;
            }else if(decKey == 0  && sbtwo==1  && subinnerdispone==2){               //Decrement key
                DELAY_US(200000);
                fltdispslk-=1;
            }
            if(fltdispslk>4){                      //cursor jumps to position first after increment key pressed on fourth position
                fltdispslk=1;
            }else if(fltdispslk==0){               //cursor jumps to position fourth after decrement key pressed on first position
                fltdispslk=4;
            }
            switch(fltdispslk){                    //selects cursor position
            case 1:
                WriteCommandLCD(0x80);           //Line One position
                break;
            case 2:
                WriteCommandLCD(0xC0);          //Line Two position
                break;
            case 3:
                WriteCommandLCD(0x94);         //Line Three position
                break;
            case 4:
                WriteCommandLCD(0xD4);         //Line Fourth position
                break;
            default:
                WriteCommandLCD(0x80);        //By default cursor position is Line One
                break;
            }
        }

    if(enterKey == 0 && fltdispslk==1 && fltDisp==0 && sbtwo==1 && subinnerdispone==2 && stopKeySense==0){
        scanKey=2;
        debouncestart=1;
        stopKeySense=1;
        debounce();
        if(enterKey==0 && open==1){
            DELAY_US(200000);
            FaultScreen();
            fltDisp=1;
            rd_ee=1;
        }
    }
    if(enterKey == 0 && fltdispslk==2 && fltDisp==0 && sbtwo==1 && subinnerdispone==2 && stopKeySense==0){
        scanKey=2;
        debouncestart=1;
        stopKeySense=1;
        debounce();
        if(enterKey==0 && open==1){
            DELAY_US(200000);
            FaultScreen();
            fltDisp=1;
        }
    }
    if(enterKey == 0 && fltdispslk==3 && fltDisp==0 && sbtwo==1 && subinnerdispone==2 && stopKeySense==0){
        scanKey=2;
        debouncestart=1;
        stopKeySense=1;
        debounce();
        if(enterKey==0 && open==1){
            DELAY_US(200000);
            FaultScreen();
            fltDisp=1;
        }
    }
    if(enterKey == 0 && fltdispslk==4 && fltDisp==0 && sbtwo==1 && subinnerdispone==2 && stopKeySense==0){
        scanKey=2;
        debouncestart=1;
        stopKeySense=1;
        debounce();
        if(enterKey==0 && open==1){
            DELAY_US(200000);
            FaultScreen();
            fltDisp=1;
        }
    }
    //***********************************CAUTION: WORK IN PROGRESS***************************************
    /*if(enterKey == 0 && fltDisp==0 && sbtwo==1 && subinnerdispone==2 && stopKeySense==0){
        if(fltdispslk==1){
            scanKey=2;
            debouncestart=1;
            stopKeySense=1;
            debounce();
            if(enterKey==0 && open==1){
                DELAY_US(200000);
                FaultScreen();
                fltDisp=1;
                rd_ee=1;
            }
        }else{
            if(fltdispslk==2){
                scanKey=2;
                debouncestart=1;
                stopKeySense=1;
                debounce();
                if(enterKey==0 && open==1){
                    DELAY_US(200000);
                    FaultScreen();
                    fltDisp=1;
                }
            }else{
                if(fltdispslk==3){
                    scanKey=2;
                    debouncestart=1;
                    stopKeySense=1;
                    debounce();
                    if(enterKey==0 && open==1){
                        DELAY_US(200000);
                        FaultScreen();
                        fltDisp=1;
                    }
                }else{
                    if(fltdispslk==4){
                        scanKey=2;
                        debouncestart=1;
                        stopKeySense=1;
                        debounce();
                        if(enterKey==0 && open==1){
                            DELAY_US(200000);
                            FaultScreen();
                            fltDisp=1;
                        }
                    }
                }
            }
        }
    }*/

    //^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^



    if(enterKey == 0 && sbone==1 && subdispKeyVal==1 && doorstatus==1 && stopKeySense==0){
        scanKey=2;
        stopKeySense=1;
        copy=1;
        DELAY_US(250000);
        digitBlinkData=rtcdatatime[0];
        clockRtc();
        subinnerdisp=1;
    }

    if(enterKey == 0 && sbone==1 && subdispKeyVal==2 && doorstatus==1 && stopKeySense==0){
        scanKey=2;
        stopKeySense=1;
        DELAY_US(250000);
        digitBlinkData=batHealthTime[8];
        batteryHealth();
        subinnerdisp=2;
    }


    while(enterKey == 0 && sbtwo==1 && subdispKeyVal==1 && doorstatus==1 && stopKeySense==0){
        scanKey=2;
        debouncestart=1;
        stopKeySense=1;
        debounce();
        if(enterKey==0 && open==1){
            rd_ee=1;
            digitBlinkData=logDatabyDate1[0];
            LogDatabyDate();
            subinnerdispone=1;
        }
    }

    while(enterKey == 0 && sbtwo==1 && subdispKeyVal==2 && j==0 && doorstatus==1 && stopKeySense==0){
        scanKey=2;
        debouncestart=1;
        stopKeySense=1;
        debounce();
        if(enterKey==0 && open==1){
            LogDatabyFault();
            subinnerdispone=2;
        }
        DELAY_US(200000);
    }

    //*****************************************CAUTION: WORK IN PROGRESS*************************************************************
    /*if(enterKey==0 && doorstatus==1 && stopKeySense==0 && subdispKeyVal !=0){
        if(sbone==1){
            if(subdispKeyVal==1){
                scanKey=2;
                stopKeySense=1;
                copy=1;
                DELAY_US(250000);
                digitBlinkData=rtcdatatime[0];
                clockRtc();
                subinnerdisp=1;
            }else{
                if(subdispKeyVal==2){
                    scanKey=2;
                    stopKeySense=1;
                    DELAY_US(250000);
                    digitBlinkData=batHealthTime[8];
                    batteryHealth();
                    subinnerdisp=2;
                }
            }

        }
        if(sbtwo==1){
            if(subdispKeyVal==1){
                scanKey=2;
                debouncestart=1;
                stopKeySense=1;
                debounce();
                if(enterKey==0 && open==1){
                    rd_ee=1;
                    digitBlinkData=logDatabyDate1[0];
                    LogDatabyDate();
                    subinnerdispone=1;
                }
            }else{
                if(subdispKeyVal==2){
                    scanKey=2;
                    debouncestart=1;
                    stopKeySense=1;
                    debounce();
                    if(enterKey==0 && open==1){
                        LogDatabyFault();
                        subinnerdispone=2;
                    }
                    DELAY_US(200000);
                }
            }
        }
    }*/

    //^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    if(setBackey==0 && fltDisp==1 && sbtwo==1 && subinnerdispone==2){
        DELAY_US(200000);
        LogDatabyFault();
        fltDisp=0;
        testkeyval=oldkeyval;

     }


   if(setBackey==0 && subinnerdisp==1 && fltDisp==0||setBackey==0 && subinnerdisp==2 && fltDisp==0){
       DELAY_US(200000);
       setTime();
       subinnerdisp=0;
       curcount=0;
       datacurcount=0;
       testkeyval=oldkeyval;

   }

   if(setBackey==0 && subinnerdispone==1 && fltDisp==0||setBackey==0 && subinnerdispone==2 && fltDisp==0){
       DELAY_US(200000);
       LogData();
       subinnerdispone=0;
       curcount=0;
       datacurcount=0;
       testkeyval=oldkeyval;
   }

    if(setBackey == 0 && sbone==1 && innerdisp==1||setBackey == 0 && sbone==1 && innerdisp==2 ||setBackey == 0 && sbone==1 && innerdisp==3||setBackey == 0 && sbone==1 && innerdisp==4 && subinnerdisp==0   ){
            DELAY_US(200000);
            fieldSetting();
            innerdisp=0;
            subinnerdisp=0;
            subdispKeyVal=0;
            curcount=0;
            datacurcount=0;
            testkeyval=oldkeyval;
    }

    if(setBackey==0 && sbtwo==1 && subinnerdispone==0){
        DELAY_US(200000);
        mainScreen();
        sbone=0;
        sbtwo=0;
        innerdisp=0;
        curcount=0;
        datacurcount=0;
        subdispKeyVal=1;
        testkeyval=oldkeyval;
    }

    if(setBackey == 0 && sbone==1 && innerdisp==0){
        DELAY_US(200000);
        mainScreen();
        innerdisp=0;
        sbone=0;
        sbtwo=0;
        subinnerdisp=0;
        subdispKeyVal=0;
        curcount=0;
        testkeyval=oldkeyval;
        datacurcount=0;
    }
    }

}


void update(unsigned char data)
{
    val = data;
    return;
}
void update1(int data)
{
    val2 = data;
    val3 = 1;
   return;
}

void maxCount(void){
    if(tempData>57){
        tempData=48;
        digitBlinkData=48;
    }
}
void minCount(void){
    if(tempData<48){
        tempData=57;
        digitBlinkData=57;
    }
}

void digitBlinker(void){
    tempBlinker=digitBlinkData;
    DELAY_US(300000);
    opoutvtg[datacurcount]=tempBlinker;
    outputVoltage();
    tempBlinker=20;
    DELAY_US(200000);
    opoutvtg[datacurcount]=tempBlinker;
    outputVoltage();
    tempBlinker=digitBlinkData;
    DELAY_US(300000);
    opoutvtg[datacurcount]=tempBlinker;
    outputVoltage();
}

void keyScan(void){
    if(stopKeySense==0){
        if(innerdisp==1 || innerdisp==2 || innerdisp==3 || innerdisp==4 || factDispDoor==1 ||caliDispDoor==1 ){
            scanKey=2;
            if(scanKey>2 && innerdisp==1 || innerdisp==2 || innerdisp==3 || innerdisp==4 ||factDispDoor==1 || caliDispDoor==1){
                scanKey=2;
            }
        }else{
            if(innerdisp==0 && doorstatus==1){
                scanKey=5000;
                if(scanKey>5000){
                    scanKey=5000;
                }
            }
        }
    }
    if(stopKeySense==1){
        if(scanKey>5000){
            if(innerdisp==1 || innerdisp==2 || innerdisp==3 || innerdisp==4 ||factDispDoor==1 || caliDispDoor==1){
                scanKey=2;
            }
            if(innerdisp==0 && doorstatus==1){
                scanKey=5000;
            }
        }
        scanKey-=1;
        if(scanKey<=0){
            stopKeySense=0;
        }
    }


}


