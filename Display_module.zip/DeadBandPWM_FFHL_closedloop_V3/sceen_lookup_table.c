/*
 * sceen_lookup_table.c
 *
 *  Created on: Jul 22, 2020
 *      Author: mihir
 */
#include "DSP28x_Project.h"
#include "sceen_lookup_table.h"
#include "piccolo_lcd.h"
void s1();
void s2();
void shm();
void sld1();
void sld2();
void sld3();
void sld4();
void sld5();
void sld6();
void fld1();
void fld2();
void fld3();
void fld4();
void fld5();
void fld6();
void fld7();
void fld8();
void fld9();
void fld10();
void fld11();
void fld12();
void clb1();
void clb2();
void clb3();
void clb4();
void clb5();
void clb6();
void clb7();
void clb8();
void clb9();
void clb10();
void clb11();
void clb12();
void clb13();
void clb14();
void clb15();
void clb16();
void clb17();
void clb18();
void clb19();
void clb20();
void clb21();
void clb22();
void clb23();
void clb24();
void flt_scrn1();
//void lcd_write(Uint16 disp_ctr,char *line_one,char *line_two,char *line_three,char *line_four);
char lcd_stage=0;
char Da[25];
char startup1[]="GAEC   RBC_EBC 4.5KW ";
char startup2[]="FOR LHB COACHES     ";
char startup3[]="RDSO/PE/SPEC/AC/0183";
char startup4[]="rev1(2018)          ";


char selfcheck2[]="     SELF CHECK     ";
char selfcheck3[]="         IN         ";
char selfcheck4[]="      PROGRESS      ";


char homescreen2[]=" DD:MM:YY  HH:MM:SS ";
char homescreen3[]="O/P:XXX.XV  XXX.XA  ";
char homescreen4[]="^/v- DATA       HOME";
char home[]="^/v- DATA           ";

char livedata1[]="      OUTPUT        ";
char livedata2[]="XXX.XV    TOT:XXX.XA";
char livedata3[]=" X.XXKW   BAT: XX.XA";


char livedataIavg1[]="    INPUT avg       ";
char livedataIavg2[]="  L-L XXXV   XX.XA  ";
char livedataIavg3[]="  P-N XXXV   XX.XA  ";


char livedataPn1[]="    INPUT P-N       ";
char livedataPn2[]="V R:XXX Y:XXX B:XXX ";
char livedataPn3[]="A  XX.X  XX.X  XX.X ";


char livedataTemp1[]="    TEMPERATURE     ";
char livedataTemp2[]="DEVICE:XXX'C        ";
char livedataTemp3[]="TRAFO: XXX'C        ";


char livedataBatthealth1[]="BATT HEALTH CHECK-ON";
char livedataBatthealth2[]="05:05    00:09 to go";
char livedataBatthealth3[]="O/P:095.0V    10.0A ";
char livedataBatthealth4[]="                HOME";


char batteryHealthcheck2[]="BATTERY  NOT HEALTHY";
char batteryHealthCheck3[]="DDISCHED in 01 min  ";



char batteryHealthcheck12[]="BATTERY  HEALTHY    ";
char batteryHealthcheck13[]="                    ";


volatile char RbcTripSelfCheck2[]=" SELF CHECK-FAIL    ";
volatile char RbcTripSelfCheck3[]="EBC ON              ";



volatile char RbcTripUnderVtg2[]=" I/P UNDER VOLTAGE  ";
volatile char RbcTripUnderVtg3[]="RBC OFF     XXXV    ";


volatile char RbcTripOverVtg2[]=" I/P OVER VOLTAGE   ";
volatile char RbcTripOverVtg3[]="RBC OFF     XXXV    ";


char RbcTripSinglePhase2[]=" i/p X PHASE LOSS   ";
char RbcTripSinglePhase3[]=" 35% OUTPUT         ";



volatile char RbcTripReverseBatt2[]="  BATTERY REVERSE   ";
volatile char RbcTripReverseBatt3[]="RBC OFF             ";



volatile char RbcTripOutOverVtg2[]=" I/P OVER VOLTAGE   ";
volatile char RbcTripOutOverVtg3[]="EBC ON              ";



volatile char RbcTripOverTemp2[]="DEVICE TEMP  HIGH   ";
volatile char RbcTripOverTemp3[]="EBC ON      XXX'C   ";






volatile char RbcTripEarthLeakage2[]="   EARTH LEAKAGE on ";
volatile char RbcTripEarthLeakage3[]="   +ve    -ve      ";


volatile char RbcTripLowIvtg2[]="i/p bet:300 & 350   ";
volatile char RbcTripLowIvtg3[]=" 35% OUTPUT         ";


volatile char RbcTripFuseFail2[]="   O/P FUSE FAIL    ";
volatile char RbcTripFuseFail3[]="EBC ON              ";



volatile char RbcTripRbcFaulty2[]="     RBC FAULTY     ";
volatile char RbcTripRbcFaulty3[]="EBC ON              ";


volatile char usbDetect1[]="PEN DRIVE DETECTED  ";
volatile char usbDetect2[]="DOWNLOADING >>>>>   ";

char usbDetect3[]="                    ";
volatile char usbDetect4[]="                HOME";

volatile char usbDownload[]=" DOWNLOAD COMPLETE  ";

volatile char usbFault[]="       FAULT in     ";
volatile char usbFault2[]="     DOWNLOADING    ";

volatile char usbMemory[]="    INSUFFICIENT    ";
volatile char usbMemory1[]="       MEMORY       ";

char fieldSetting1[]="   FIELD SETTING    ";
char fieldSetting2[]="^/v for selection   ";
char fieldSetting3[]="e to confirm select ";
char fieldSetting4[]="Back to Exit Setting";

char fieldSetting5[]="1:FIELD SETTING     ";
char fieldSetting6[]="2:VIEW FAULT HISTORY";
char fieldSetting7[]="3:RBC USER MANUAL   ";
char fieldSetting8[]="E-SELECT   Back-HOME";

char fieldSetting9[]="EDIT n STORE VALUE  ";
char fieldSetting10[]="^/v/- -SET NEW VALUE";
char fieldSetting11[]="E TO STORE          ";
char fieldSetting12[]="BACK-PRV W/O STORING";

char fieldSetting13[]="1:o/p VOLTAGE       ";
char fieldSetting14[]="2:BAT.CURRENT       ";

char fieldSetting15[]="3:BAT.HEALTH CHECK  ";
char fieldSetting16[]="4:CLOCK             ";

char fieldSetting17[]="  SET o/p VOLTAGE   ";
char fieldSetting18[]="      120.0V        ";
char fieldSetting19[]="LIMIT  110 to 135   ";

char fieldSetting20[]="  SET BAT CURRENT   ";
char fieldSetting21[]="      10.0A         ";
char fieldSetting22[]="LIMIT 10 TO 15      ";

char fiedlSetting23[]="  SET CLOCK  24HR   ";
char fieldSetting24[]="00:00:00  00:00     ";

char fieldSetting25[]="BAT HEALTH CHECK    ";
char fieldSetting26[]="Start @:00:00   24HR";
char fieldSetting27[]="CUT OFF:000V 90-110V";

char fieldSetting28[]=" VIEW FAULT HISTORY ";
char fieldSetting29[]="1:BY DATE           ";
char fieldSetting30[]="2:BY FAULT          ";

char fieldSetting31[]=" HISTORY BY DATE    ";
char fieldSetting32[]="Enter:DD:MM:YY      ";

char fieldsetting33[]="10:09:20 01:04:57 to";
char fiedlsetting34[]="10:09:20 01:10:27   ";
char fieldsetting35[]="FAULT NAME   OVER VT";

char factorysettingrnv[]="1:i/p VOLTAGE R-N   ";
char factorysettingynv[]="2:i/p VOLTAGE Y-N   ";

char factorysettingbnv[]="3:i/p VOLTAGE B-N   ";
char factorysettingrna[]="4:i/p VOLTAGE R-N   ";

char factorysettingyna[]="5:i/p VOLTAGE Y-N   ";
char factorysettingbna[]="6:i/p VOLTAGE B-N   ";

char factorysettingopv[]="7:o/p VOLTAGE       ";
char factorysettingopa[]="8:o/p CURRENT-TOT   ";

char factorysettingbatcrg[]="9:Bat CURRENT-Charge ";
char factorysettingbatdcrg[]="10:Bat CURRENT-Charge ";

char factorysettingdclinkv[]="11:DC LNK VOLTAGE   ";
char factorysettingdclinka[]="12:DC LNK CURRENT   ";

char factorysettingearthpst[]="13:EARTH LEAKAGE-+VE";
char factorysettingearthnvt[]="14:EARTH LEAKAGE--VE";

char factorysettingtempdevice[]="15:TEMP-DEVICE/HS   ";
char factorysettingtemptransfo[]="16:TEMP-TRANSFORMER ";

char factorysettingprimtransfo[]="17:PRIM of TRAFO    ";
char factorysettingtrc[]="18:RTC              ";

char factorysettingdclinkcmp[]="19:DC LNK CURRENT cmp";
char factorysettingoutamp[]="20:O/P CURRENT   CMP";

char Calibration1[]="  i/p VOLTAGE  R-N C";
char Calibration2[]="ZERO  SPAN      FS  ";
char Calibration3[]=" XXX   XXX     000  ";
char calibration4[]="E-STORE    BACK-MENU";

char calibration5[]="  i/p VOLTAGE  Y-N C";
char Calibration27[]=" XXX   XXX     000  ";

char calibration6[]="  i/p VOLTAGE  B-N C";
char Calibration28[]=" XXX   XXX     000  ";

char calibration7[]="  i/p CURRENT-Rph  C";
char Calibration29[]=" XXX   XXX     000  ";

char calibration8[]="  i/p CURRENT-Yph  C";
char Calibration30[]=" XXX   XXX     000  ";

char calibration9[]="  i/p CURRENT-Bph  C";
char Calibration31[]=" XXX   XXX     000  ";

char calibration10[]="    Output Voltage      ";
char Calibration32[]=" XXX   XXX     000  ";

char calibration11[]="      Output Current    ";
char Calibration33[]=" XXX   XXX     000  ";

char calibration12[]="Bat CURRENT-CHARGE  C";
char Calibration34[]=" XXX   XXX     000  ";

char calibration13[]="Bat CURRENT-DISCH    C";
char Calibration35[]=" XXX   XXX     000  ";

char calibration14[]=" DC LINK VOLTAGE   C";
char Calibration36[]=" XXX   XXX     000  ";

char calibration15[]=" DC LINK CURRENT   C";
char Calibration37[]=" XXX   XXX     000  ";

char calibration16[]="EARTH LEAKAGE-+VE    ";
char Calibration38[]=" XXX   XXX     000  ";

char calibration17[]="EARTH LEAKAGE--VE    ";
char Calibration39[]=" XXX   XXX     000  ";

char calibration18[]="PRIM TRANSFORMER   ";
char Calibration40[]=" XXX   XXX     000  ";

char calibration19[]="    TEMP DEVICE     ";
char Calibration41[]=" XXX   XXX     000  ";

char calibration20[]="TEMP TRANSFORMER     ";
char Calibration42[]=" XXX   XXX     000  ";

volatile char calibration21[]="      DEVICE        ";
char Calibration43[]=" XXX   XXX     000  ";

char calibration22[]="1:CALIBRATION       ";

char calibration23[]="2:SERIAL NUMBER     ";

volatile char calibration24[]="SERIAL NUMBER of RBC";

volatile char calibration25[]="     YYMMNNNN       ";

volatile char calibration26[]="     XXXXXXXX       ";

void s1(void){
    WriteCommandLCD(0x0C);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,startup1);
    DisplayLCD(2,0,startup2);
    DisplayLCD(3,0,startup3);
    DisplayLCD(4,0,startup4);
}

void s2(void){
    WriteCommandLCD(0x0C);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,startup1);
    DisplayLCD(2,0,selfcheck2);
    DisplayLCD(3,0,selfcheck3);
    DisplayLCD(4,0,selfcheck4);
}

void shm(void){
    if(lcd_stage==0){
        WriteCommandLCD(0x0C);
        lcd_stage=1;
    }else{
        if(lcd_stage==1){
            lcdClear();
            lcd_stage=2;
        }else{
            if(lcd_stage==5){
                DisplayLCD(1,0,startup1);
                DisplayLCD(2,0,homescreen2);
                DisplayLCD(3,0,homescreen3);
                arrow_screen=1;
                DisplayLCD(4,0,homescreen4);
                arrow_screen=0;
                lcd_stage=6;
            }

        }
    }
    //WriteCommandLCD(0x0C);
    //lcdClear();
    //DELAY_US(2000);
    //DisplayLCD(1,0,startup1);
    //DisplayLCD(2,0,homescreen2);
    //DisplayLCD(3,0,homescreen3);
    //arrow_screen=1;
   // DisplayLCD(4,0,homescreen4);
   // arrow_screen=0;
}

void sld1(void){
    if(lcd_stage==0){
        WriteCommandLCD(0x0C);
        lcd_stage=1;
    }else{
        if(lcd_stage==1){
            lcdClear();
            lcd_stage=2;
        }else{
            if(lcd_stage==5){
                DisplayLCD(1,0,livedata1);
                DisplayLCD(2,0,livedata2);
                DisplayLCD(3,0,livedata3);
                arrow_screen=1;
                DisplayLCD(4,0,home);
                arrow_screen=0;
                lcd_stage=6;
            }

        }
    }
    //WriteCommandLCD(0x0C);
    //lcdClear();
    //DELAY_US(2000);
    //DisplayLCD(1,0,livedata1);
    //DisplayLCD(2,0,livedata2);
    //DisplayLCD(3,0,livedata3);
    //arrow_screen=1;
    //DisplayLCD(4,0,home);
    //arrow_screen=0;
}

void sld2(void){
    if(lcd_stage==0){
        WriteCommandLCD(0x0C);
        lcd_stage=1;
    }else{
        if(lcd_stage==1){
            lcdClear();
            lcd_stage=2;
        }else{
            if(lcd_stage==5){
                DisplayLCD(1,0,livedataIavg1);
                DisplayLCD(2,0,livedataIavg2);
                DisplayLCD(3,0,livedataIavg3);
                arrow_screen=1;
                DisplayLCD(4,0,home);
                arrow_screen=0;
                lcd_stage=6;
            }

        }
    }
    //lcdClear();
    //DELAY_US(2000);
    //DisplayLCD(1,0,livedataIavg1);
    //DisplayLCD(2,0,livedataIavg2);
    //DisplayLCD(3,0,livedataIavg3);
    //arrow_screen=1;
    //DisplayLCD(4,0,home);
    //arrow_screen=0;
}

void sld3(void){
    if(lcd_stage==0){
        WriteCommandLCD(0x0C);
        lcd_stage=1;
    }else{
        if(lcd_stage==1){
            lcdClear();
            lcd_stage=2;
        }else{
            if(lcd_stage==5){
                DisplayLCD(1,0,livedataPn1);
                DisplayLCD(2,0,livedataPn2);
                DisplayLCD(3,0,livedataPn3);
                arrow_screen=1;
                DisplayLCD(4,0,home);
                arrow_screen=0;
                lcd_stage=6;
            }

        }
    }
    //WriteCommandLCD(0x0C);
    //lcdClear();
    //DELAY_US(2000);
    //DisplayLCD(1,0,livedataPn1);
    //DisplayLCD(2,0,livedataPn2);
    //DisplayLCD(3,0,livedataPn3);
    //arrow_screen=1;
    //DisplayLCD(4,0,home);
    //arrow_screen=0;
}

void sld4(void){
    if(lcd_stage==0){
        WriteCommandLCD(0x0C);
        lcd_stage=1;
    }else{
        if(lcd_stage==1){
            lcdClear();
            lcd_stage=2;
        }else{
            if(lcd_stage==5){
                DisplayLCD(1,0,livedataTemp1);
                DisplayLCD(2,0,livedataTemp2);
                DisplayLCD(3,0,livedataTemp3);
                arrow_screen=1;
                DisplayLCD(4,0,home);
                arrow_screen=0;
                lcd_stage=6;
            }

        }
    }
    //WriteCommandLCD(0x0C);
    //lcdClear();
    //DELAY_US(2000);
    //DisplayLCD(1,0,livedataTemp1);
    //DisplayLCD(2,0,livedataTemp2);
    //DisplayLCD(3,0,livedataTemp3);
    //arrow_screen=1;
    //DisplayLCD(4,0,home);
    //arrow_screen=0;
}

void sld5(void){
    if(lcd_stage==0){
        WriteCommandLCD(0x0C);
        lcd_stage=1;
    }else{
        if(lcd_stage==1){
            lcdClear();
            lcd_stage=2;
        }else{
            if(lcd_stage==5){
                DisplayLCD(1,0,livedataBatthealth1);
                DisplayLCD(2,0,livedataBatthealth2);
                DisplayLCD(3,0,livedataBatthealth3);
                arrow_screen=1;
                DisplayLCD(4,0,home);
                arrow_screen=0;
                lcd_stage=6;
            }

        }
    }
    //WriteCommandLCD(0x0C);
    //lcdClear();
    //DELAY_US(2000);
    //DisplayLCD(1,0,livedataBatthealth1);
    //DisplayLCD(2,0,livedataBatthealth2);
    //DisplayLCD(3,0,livedataBatthealth3);
    //arrow_screen=1;
    //DisplayLCD(4,0,home);
    //arrow_screen=0;
}

void sld6(void){

    if(lcd_stage==0){
        WriteCommandLCD(0x0C);
        lcd_stage=1;
    }else{
        if(lcd_stage==1){
            lcdClear();
            lcd_stage=2;
        }else{
            if(lcd_stage==5){
                DisplayLCD(1,0,startup1);
                DisplayLCD(2,0,batteryHealthcheck2);
                DisplayLCD(3,0,batteryHealthCheck3);
                arrow_screen=1;
                DisplayLCD(4,0,home);
                arrow_screen=0;
                lcd_stage=6;
            }

        }
    }
    //WriteCommandLCD(0x0C);
    //lcdClear();
    //DELAY_US(2000);
    //DisplayLCD(1,0,startup1);
    //DisplayLCD(2,0,batteryHealthcheck2);
    //DisplayLCD(3,0,batteryHealthCheck3);
    //arrow_screen=1;
    //DisplayLCD(4,0,home);
    //arrow_screen=0;
}

void flt_scrn1(void){
    if(lcd_stage==0){
        WriteCommandLCD(0x0C);
        lcd_stage=1;
    }else{
        if(lcd_stage==1){
            lcdClear();
            lcd_stage=2;
        }else{
            if(lcd_stage==5){
                DisplayLCD(1,0,startup1);
                DisplayLCD(2,0,RbcTripSinglePhase2);
                DisplayLCD(3,0,RbcTripSinglePhase3);
                arrow_screen=1;
                DisplayLCD(4,0,home);
                arrow_screen=0;
                lcd_stage=6;
            }

        }
    }
}



void fld1(void){
    WriteCommandLCD(0x0C);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,fieldSetting1);
    arrow_screen=1;
    DisplayLCD(2,0,fieldSetting2);
    arrow_screen=0;
    arrow_screen=2;
    DisplayLCD(3,0,fieldSetting3);
    arrow_screen=0;
    DisplayLCD(4,0,fieldSetting4);
}

void fld2(void){
    WriteCommandLCD(0x0F);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,fieldSetting5);
    DisplayLCD(2,0,fieldSetting6);
    DisplayLCD(3,0,fieldSetting7);
    arrow_screen=3;
    DisplayLCD(4,0,fieldSetting8);
    arrow_screen=0;
}

void fld3(void){
    WriteCommandLCD(0x0F);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,calibration22);
    DisplayLCD(2,0,calibration23);
    DisplayLCD(3,0,usbDetect3);
    arrow_screen=3;
    DisplayLCD(4,0,fieldSetting8);
    arrow_screen=0;
}

void fld4(void){
    WriteCommandLCD(0x0F);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,fieldSetting13);
    DisplayLCD(2,0,fieldSetting14);
    arrow_screen=3;
    DisplayLCD(4,0,fieldSetting8);
    arrow_screen=0;
}

void fld5(void){
    WriteCommandLCD(0x0F);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,fieldSetting15);
    DisplayLCD(2,0,fieldSetting16);
    arrow_screen=3;
    DisplayLCD(4,0,fieldSetting8);
    arrow_screen=0;
}


void fld6(void){
    WriteCommandLCD(0x0E);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,fieldSetting17);
    DisplayLCD(2,0,fieldSetting18);
    DisplayLCD(3,0,fieldSetting19);
    arrow_screen=3;
    DisplayLCD(4,0,calibration4);
    arrow_screen=0;
}

void fld7(void){
    WriteCommandLCD(0x0E);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,fieldSetting20);
    DisplayLCD(2,0,fieldSetting21);
    DisplayLCD(3,0,fieldSetting22);
    arrow_screen=3;
    DisplayLCD(4,0,calibration4);
    arrow_screen=0;
}

void fld8(void){
    WriteCommandLCD(0x0E);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,fiedlSetting23);
    DisplayLCD(2,0,fieldSetting24);
    arrow_screen=3;
    DisplayLCD(4,0,calibration4);
    arrow_screen=0;
}

void fld9(void){
    WriteCommandLCD(0x0E);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,fieldSetting25);
    DisplayLCD(2,0,fieldSetting26);
    DisplayLCD(3,0,fieldSetting27);
    arrow_screen=3;
    DisplayLCD(4,0,calibration4);
    arrow_screen=0;
}

void fld10(void){
    WriteCommandLCD(0x0F);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,fieldSetting28);
    DisplayLCD(2,0,fieldSetting29);
    DisplayLCD(3,0,fieldSetting30);
    arrow_screen=3;
    DisplayLCD(4,0,calibration4);
    arrow_screen=0;
}

void fld11(void){
    WriteCommandLCD(0x0E);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,fieldSetting31);
    DisplayLCD(2,0,fieldSetting32);
    arrow_screen=3;
    DisplayLCD(4,0,calibration4);
    arrow_screen=0;
}

void fld12(void){
    WriteCommandLCD(0x0C);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,fieldsetting33);
    DisplayLCD(2,0,fiedlsetting34);
    if(Da[9]==0x01){
        DisplayLCD(3,0,"FAULT NAME   OVER VT");
    }else{
        if(Da[9]==2){
            DisplayLCD(3,0,"FAULT NAME   OVER AM");
        }else{
            if(Da[9]==5){
                DisplayLCD(3,0,"FAULT NAME   SHORT CK");
            }
        }
    }
    //arrow_screen=3;
    DisplayLCD(4,0,"           BACK-MENU");
    //arrow_screen=0;
}

void clb1(void){
    WriteCommandLCD(0x0F);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,factorysettingrnv);
    DisplayLCD(2,0,factorysettingynv);
    DisplayLCD(3,0,factorysettingbnv);
    arrow_screen=3;
    DisplayLCD(4,0,fieldSetting8);
    arrow_screen=0;
}

void clb2(void){
    WriteCommandLCD(0x0F);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,factorysettingrna);
    DisplayLCD(2,0,factorysettingyna);
    DisplayLCD(3,0,factorysettingbna);
    arrow_screen=3;
    DisplayLCD(4,0,fieldSetting8);
    arrow_screen=0;
}

void clb3(void){
    WriteCommandLCD(0x0F);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,factorysettingopv);
    DisplayLCD(2,0,factorysettingopa);
    DisplayLCD(3,0,factorysettingbatcrg);
    arrow_screen=3;
    DisplayLCD(4,0,fieldSetting8);
    arrow_screen=0;
}

void clb4(void){
    WriteCommandLCD(0x0F);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,factorysettingbatdcrg);
    DisplayLCD(2,0,factorysettingdclinkv);
    DisplayLCD(3,0,factorysettingdclinka);
    arrow_screen=3;
    DisplayLCD(4,0,fieldSetting8);
    arrow_screen=0;
}

void clb5(void){
    WriteCommandLCD(0x0F);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,factorysettingearthpst);
    DisplayLCD(2,0,factorysettingearthnvt);
    DisplayLCD(3,0,factorysettingtempdevice);
    arrow_screen=3;
    DisplayLCD(4,0,fieldSetting8);
    arrow_screen=0;
}

void clb6(void){
    WriteCommandLCD(0x0F);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,factorysettingtemptransfo);
    DisplayLCD(2,0,factorysettingprimtransfo);
    DisplayLCD(3,0,factorysettingtrc);
    arrow_screen=3;
    DisplayLCD(4,0,fieldSetting8);
    arrow_screen=0;
}

void clb7(void){
    WriteCommandLCD(0x0F);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,factorysettingdclinkcmp);
    DisplayLCD(2,0,factorysettingoutamp);
    DisplayLCD(3,0,usbDetect3);
    arrow_screen=3;
    DisplayLCD(4,0,fieldSetting8);
    arrow_screen=0;
}

void clb8(void){
    WriteCommandLCD(0x0E);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,Calibration1);
    DisplayLCD(2,0,Calibration2);
    DisplayLCD(3,0,Calibration3);
    arrow_screen=3;
    DisplayLCD(4,0,fieldSetting8);
    arrow_screen=0;
}

void clb9(void){
    WriteCommandLCD(0x0E);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,calibration5);
    DisplayLCD(2,0,Calibration2);
    DisplayLCD(3,0,Calibration27);
    arrow_screen=3;
    DisplayLCD(4,0,fieldSetting8);
    arrow_screen=0;
}

void clb10(void){
    WriteCommandLCD(0x0E);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,calibration6);
    DisplayLCD(2,0,Calibration2);
    DisplayLCD(3,0,Calibration28);
    arrow_screen=3;
    DisplayLCD(4,0,fieldSetting8);
    arrow_screen=0;
}

void clb11(void){
    WriteCommandLCD(0x0E);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,calibration7);
    DisplayLCD(2,0,Calibration2);
    DisplayLCD(3,0,Calibration29);
    arrow_screen=3;
    DisplayLCD(4,0,fieldSetting8);
    arrow_screen=0;
}

void clb12(void){
    WriteCommandLCD(0x0E);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,calibration8);
    DisplayLCD(2,0,Calibration2);
    DisplayLCD(3,0,Calibration30);
    arrow_screen=3;
    DisplayLCD(4,0,fieldSetting8);
    arrow_screen=0;
}

void clb13(void){
    WriteCommandLCD(0x0E);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,calibration9);
    DisplayLCD(2,0,Calibration2);
    DisplayLCD(3,0,Calibration31);
    arrow_screen=3;
    DisplayLCD(4,0,fieldSetting8);
    arrow_screen=0;
}

void clb14(void){
    WriteCommandLCD(0x0E);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,calibration10);
    DisplayLCD(2,0,Calibration2);
    DisplayLCD(3,0,Calibration32);
    arrow_screen=3;
    DisplayLCD(4,0,fieldSetting8);
    arrow_screen=0;
}

void clb15(void){
    WriteCommandLCD(0x0E);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,calibration11);
    DisplayLCD(2,0,Calibration2);
    DisplayLCD(3,0,Calibration33);
    arrow_screen=3;
    DisplayLCD(4,0,fieldSetting8);
    arrow_screen=0;
}

void clb16(void){
    WriteCommandLCD(0x0E);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,calibration12);
    DisplayLCD(2,0,Calibration2);
    DisplayLCD(3,0,Calibration34);
    arrow_screen=3;
    DisplayLCD(4,0,fieldSetting8);
    arrow_screen=0;
}

void clb17(void){
    WriteCommandLCD(0x0E);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,calibration13);
    DisplayLCD(2,0,Calibration2);
    DisplayLCD(3,0,Calibration35);
    arrow_screen=3;
    DisplayLCD(4,0,fieldSetting8);
    arrow_screen=0;
}

void clb18(void){
    WriteCommandLCD(0x0E);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,calibration14);
    DisplayLCD(2,0,Calibration2);
    DisplayLCD(3,0,Calibration36);
    arrow_screen=3;
    DisplayLCD(4,0,fieldSetting8);
    arrow_screen=0;
}

void clb19(void){
    WriteCommandLCD(0x0E);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,calibration15);
    DisplayLCD(2,0,Calibration2);
    DisplayLCD(3,0,Calibration37);
    arrow_screen=3;
    DisplayLCD(4,0,fieldSetting8);
    arrow_screen=0;
}


void clb20(void){
    WriteCommandLCD(0x0F);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,calibration16);
    DisplayLCD(2,0,Calibration2);
    DisplayLCD(3,0,Calibration38);
    arrow_screen=3;
    DisplayLCD(4,0,fieldSetting8);
    arrow_screen=0;
}

void clb21(void){
    WriteCommandLCD(0x0E);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,calibration17);
    DisplayLCD(2,0,Calibration2);
    DisplayLCD(3,0,Calibration39);
    arrow_screen=3;
    DisplayLCD(4,0,fieldSetting8);
    arrow_screen=0;
}

void clb22(void){
    WriteCommandLCD(0x0E);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,calibration18);
    DisplayLCD(2,0,Calibration2);
    DisplayLCD(3,0,Calibration40);
    arrow_screen=3;
    DisplayLCD(4,0,fieldSetting8);
    arrow_screen=0;
}

void clb23(void){
    WriteCommandLCD(0x0E);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,calibration19);
    DisplayLCD(2,0,Calibration2);
    DisplayLCD(3,0,Calibration41);
    arrow_screen=3;
    DisplayLCD(4,0,fieldSetting8);
    arrow_screen=0;
}

void clb24(void){
    WriteCommandLCD(0x0E);
    lcdClear();
    DELAY_US(2000);
    DisplayLCD(1,0,calibration20);
    DisplayLCD(2,0,Calibration2);
    DisplayLCD(3,0,Calibration42);
    arrow_screen=3;
    DisplayLCD(4,0,fieldSetting8);
    arrow_screen=0;
}



//////////////////////////////////////////////////////////////////////////////UNDER DEVELOPMENT 03022021///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*void lcd_write(Uint16 disp_ctr,char *line_one,char *line_two,char *line_three,char *line_four){//High speed LCD writing
    if(lcd_stage==0){// enable cursor
        WriteCommandLCD(0x0C);
        lcd_stage=1;
    }else{
        if(lcd_stage==1){//clear lcd
            lcdClear();
            lcd_stage=2;
        }else{
            if(lcd_stage==5){
                if(disp_ctr==1){//no special character
                    DisplayLCD(1,0,line_one);
                    DisplayLCD(2,0,line_two);
                    DisplayLCD(3,0,line_three);
                    arrow_screen=1;
                    DisplayLCD(4,0,line_four);
                    arrow_screen=0;

                }else{
                    if(disp_ctr==2){//up down special character

                    }else{
                        if(disp_ctr==3){//enter special character

                        }else{
                            if(disp_ctr==4){//instruction display

                            }else{
                                if(disp_ctr==5){//reserved for special screens

                                }
                            }
                        }
                    }
                }
                lcd_stage=6;
            }

        }
    }

}*/



