/* header file of screenTemp module consisting of various function's prototype defined
 * screenTemp.h
 *
 *  Created on: 04-Jul-2019
 *      Author: LENOVO
 */

#ifndef SCREENTEMP_H_
#define SCREENTEMP_H_
void mainScreen(void);
void fieldSetting(void);
void outputVoltage(void);
void batteryCurrent(void);
void clockRtc(void);
void batteryHealth(void);
void viewLoggedData(void);
void viewHistory(void);
void defaultscreen(void);
void demoStartup(void);
void setTime(void);
void outputCurrent(void);
void LogData();
void LogDatabyDate();
void LogDatabyFault();
void FaultScreen();
void factSetting();
void factOneSetting();
void InUnderVtg();
void InOverVtg();
void outOverVtg();
void outOverAmp();
void TransTemp();
void HsTemp();
void earthLeakage();
void shortCkt();
void factsetting2(void);
void setSrNo(void);
void clrMem(void);
void calibration1(void);
void calibration2(void);
void calibration3(void);
void calInVtg(void);
void calOutVtg(void);
void calInAmp(void);
void calOutAmp(void);
void calBattChrg(void);
void calTxTmp(void);
void calDvcTmp(void);
void calEthLkg(void);
void calBattDis(void);
extern char opoutvtg[];
extern char opoutamp[];
extern char batcurrent[];
extern char rtcdatatime[];
extern char rtcdatadate[];
extern char batHealthTime[];
extern char logDatabyDate1[];
extern char inUnderVtg1[];
extern char inOverVtg1[];
extern char OutOverVtg1[];
extern char OutOverAmp1[];
extern char shortCktvtg1[];
extern char TxTemp1[];
extern char TempHsDevice1[];
extern char EarthLeakage1[];
extern char serialNo1[];
extern char clearMemory1[];
extern char ivtgcal[];
extern char ovtgcal[];
extern char iampcal[];
extern char Oampcal[];
extern char baCrampcal[];
extern char badrampcal[];
extern char faultscreen[];
extern char faultscreen1[];
extern char faultscreen2[];
extern char faultscreen3[];
extern char factorySetting[];
extern char factorySetting1[];
extern char factorySetting2[];
extern char factorySetting3[];
extern char factorySetting5[];
extern int DataLog[11];
#endif /* SCREENTEMP_H_ */
