//*************************Header's Including Section********************************************************************************
//-----------------------------------------------------------------------------------------------------------------------------------
#include "PeripheralHeaderIncludes.h"                                         //Peripheral Header Including
#include <stdint.h>
#include <stdio.h>
#include "F2806x_EPwm_defines.h"                                              // useful defines for initialization
#include "F2806x_Examples.h"                                                  // F2806x Examples Include File
#include "F2806x_Device.h"                                                    // F2806x Headerfile Include File
#include "DSP28x_Project.h"                                                   // Device Headerfile and Examples Include File
#include "piccolo_lcd.h"                                                      //including lcd header
#include "screenTemp.h"                                                       //including display headers
#include "rtc_eeprom.h"                                                       //including rtc header
#include "sceen_lookup_table.h"
#include "cla_shared.h"
#include "string.h"


//-----------------------------------------------------------------------------------------------------------------------------------
//**************************Function's Including Section*****************************************************************************
//-----------------------------------------------------------------------------------------------------------------------------------
void DeviceInit(void);                                                        //Device's GPIO,Clock and peripheral Initialization
void InitFlash(void);                                                         //Flash Initialize
void MemCopy(Uint16 *SourceAddr, Uint16* SourceEndAddr, Uint16* DestAddr);    //Flash
                                                          //Key sensing functions for horizontal Cursor Movement
void rtc_write(Uint16 location,Uint16 data);                                  //Function's to Write Data to RTC
void eeprom_write(Uint16 high_add,Uint16 low_add,Uint16 data);                //Function's to Write Data to EEPROM
Uint16 rtc_read(Uint16 location);                                             //Function to Read Data from RTC
Uint16 eeprom_read(Uint16 high_add,Uint16 low_add);                           //Function's to read data from EEPROM
void rtc_Init(void);                                                          //Function to Initialize RTC
void i2c_Config(void);                                                        //Function to configure I2C Module
void wait_delay(void);                                                        //Delay Function
Uint16 hex_to_dec(Uint16 rawInput);                                           //Function to convert HEX value of RTC registers to Decimal Value

void factorysetting(void);
void power_on(void);
void search(void);
void dataValidation(void);
void getdata(void);
void Divi_Fac_Update(Uint16 *adc_V,char *FirstDigit,char *SecondDigit,char *ThirdDigit,Uint16 *D_Fact);//Calibration Divide factor updater
void calibration_adc_lcd_update(Uint16 *current_adc_Val,char *lcd1,char *lcd2,char *lcd3,char *lcd4,Uint16 *divide_Fac,char *result1,char *result2,char *result3);
void ChartoDec(char *firstDigit,char *secondDigit,char *thirdDigit,char *decimalpoint,Uint16 *result);
void (*ptr)(void);
void adcConfig(void);
void done(void);
void init_cla(void);
//void InitEPwm2Example(void);
//void InitEPwm3Example(void);
//void InitEPwm4Example(void);

/*typedef struct
{
   volatile struct EPWM_REGS *EPwmRegHandle;
   Uint16 EPwm_CMPA_Direction;
   Uint16 EPwm_CMPB_Direction;
   Uint16 EPwmTimerIntCount;
   Uint16 EPwmMaxCMPA;
   Uint16 EPwmMinCMPA;
   Uint16 EPwmMaxCMPB;
   Uint16 EPwmMinCMPB;
}EPWM_INFO;*/
//-----------------------------------------------------------------------------------------------------------------------------------
//***************************Variable Defining Section*******************************************************************************
//-----------------------------------------------------------------------------------------------------------------------------------
////////////////////////////////////////////////KEYPAD SENSING/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
Uint16 decValue=0;
volatile unsigned short keyspeed=0;
volatile unsigned short keydelay=0;
volatile unsigned int passctr=0;
unsigned short keyen=0;
/////////////////////////////////////////////////VIRTUAL TIMER//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
volatile unsigned short virtualTimer=0;
volatile Uint16 updatertc=0;
volatile unsigned short introdelay=0;
Uint16 battery_timer=0;
///////////////////////////////////////////CUSTOM LCD CHARACTER////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
unsigned char pattern[]={4,14,21,04,04,04,04,04};
unsigned char pattern1[]={04,04,04,04,04,21,14,4};
unsigned char pattern2[]={1,1,1,9,31,9,0,0};
unsigned short in=0;
/////////////////////////////////////////////BLANK LCD////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
char setoutvtg[]="00000";
unsigned char setbattamp[]="00000";
unsigned char setbattcheck[]="0000000000";
unsigned char setclk[]="000000000000000";
/////////////////////////////////////////////RTC READING AND DISPLAY////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
volatile char liveRtcTime[8];
char liveRtcDate[8];
volatile int rtc_strings[8];
volatile unsigned short rd_cmplt=0;
volatile unsigned short rtcRead=500;
volatile unsigned short rtc_update=0;
unsigned int rtc_on=0;
////////////////////////////////////////////////EEPROM READING////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
unsigned int b_check=0;
Uint16 rd_progress=0;
char eepromdata0=0;
char eepromdata1=0;
char eepromdata2=0;
char eepromdata3=0;
char eepromdata4=0;
char eepromdata5=0;
Uint16 read=0;
Uint16 first_address=0;
Uint16 reset=0;
Uint16 stage1=0;
Uint16 stage2=0;
Uint16 stage3=0;
Uint16 high_add=0x00;
Uint16 low_add=0x01;
Uint16 ee_address=0;
unsigned int p=0;
/////////////////////////////////////////////////ADC READING///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
Uint16 adcValueOne[6];
Uint16 adcValueTwo[6];
Uint16 adcValueThree[6];
Uint16 adcValueFour[6];
Uint16 adcValueFive[6];
Uint16 adcvalue=0;
volatile Uint16 adcCounter=0;
Uint16 adcOpValue=0;
Uint16 adcBattAmp=0;
Uint16 adcBattHltCheck=0;
volatile unsigned char tempedit=0;
unsigned short outVtgData=0;
Uint16 divi_Fac[20];
volatile Uint16 avg_read=0;
volatile Uint16 avg_disp=0;
volatile Uint16 ovuv_timer=0;
volatile Uint16 ovuv=0;
volatile Uint16 ovuv_flg=0;
volatile Uint16 ovuvctr=10;
volatile Uint16 zcd_status=0;
volatile Uint16 phase_loss=0;
/////////////////////////////////////////////////////SCREEN FLAGS////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
unsigned int disp_counter=1;
volatile unsigned int scrnctr=0;
volatile unsigned short scur=1;
Uint16 clb_Set=0;
unsigned int maxscreens=6;
unsigned short homescreen=0;
unsigned short fieldsetting0=0;
unsigned short sub_fieldsetting0=0;
unsigned short sub_disp_fieldsetting0=0;
unsigned short sub_field0_cursor=1;
unsigned short sub_disp_field0_cursor=1;
unsigned short sub_shift_field0_disp=0;
unsigned short fieldsetting1=0;
unsigned short sub_fieldsetting1=0;
unsigned short sub_disp_fieldsetting1=0;
unsigned short sub_field1_cursor=1;
unsigned short sub_disp_field1_cursor=1;
unsigned short sub_shift_field1_disp=0;
unsigned short fieldsetting2=0;
unsigned char fieldctr=0;
unsigned char field2ctr=0;
unsigned short powerOn=0;
volatile unsigned short updateDisplay=0;
/////////////////////////////////////////FAULT SCREEN///////////////////////////////////////////////////////////////////////////////////////////
unsigned int flt_ctr=0;
unsigned int sense=0;
unsigned int sense1=0;
unsigned int sense2=0;
//int16_t pass = 0, fail = 0;
//Uint16 testbit=0;
//Uint16 t_test=0;
//EPWM_INFO epwm1_info;
//EPWM_INFO epwm2_info;
//EPWM_INFO epwm3_info;

// Configure the period for each timer
/*#define EPWM1_TIMER_TBPRD  2000  // Period register
#define EPWM1_MAX_CMPA     0xFB5E
#define EPWM1_MIN_CMPA       50
#define EPWM1_MAX_CMPB     0xFB5E
#define EPWM1_MIN_CMPB       50

#define EPWM2_TIMER_TBPRD  2000  // Period register
#define EPWM2_MAX_CMPA     1950
#define EPWM2_MIN_CMPA       50
#define EPWM2_MAX_CMPB     1950
#define EPWM2_MIN_CMPB       50

#define EPWM3_TIMER_TBPRD  2000  // Period register
#define EPWM3_MAX_CMPA      1950
#define EPWM3_MIN_CMPA       50
#define EPWM3_MAX_CMPB     1950
#define EPWM3_MIN_CMPB     50*/

// To keep track of which way the compare value is moving
#define EPWM_CMP_UP   1
#define EPWM_CMP_DOWN 0
//-----------------------------------------------------------------------------------------------------------------------------------
//********************Interrupt Function Declaration*********************************************************************************
__interrupt void cpu_timer0_isr(void);             //Declaring Function for Timer Interrupt
/*__interrupt void adc_isr(void);
__interrupt void cla1_isr1(void);
__interrupt void cla1_isr2(void);
__interrupt void cla1_isr3(void);
__interrupt void cla1_isr4(void);
__interrupt void cla1_isr5(void);
__interrupt void epwm5_isr(void);*/
//__interrupt void epwm2_isr(void);
//__interrupt void epwm3_isr(void);
//__interrupt void epwm4_isr(void);

//-----------------------------------------------------------------------------------------------------------------------------------
// Used for running BackGround in flash and the ISR in RAM
extern Uint16 RamfuncsLoadStart, RamfuncsLoadEnd, RamfuncsRunStart;
extern uint16_t Cla1ProgRunStart, Cla1ProgLoadStart, Cla1ProgLoadSize;
extern uint16_t CLA1mathTablesRunStart, CLA1mathTablesLoadStart;
extern uint16_t CLA1mathTablesLoadSize;
//********************************Main Program Section*******************************************************************************
//-----------------------------------------------------------------------------------------------------------------------------------
void main(void){
    DeviceInit();                                                                    // Device Life support & GPIO mux settings
#ifdef FLASH
    memcpy(&RamfuncsRunStart, &RamfuncsLoadStart, (uint32_t)&RamfuncsLoadSize);
    memcpy((uint32_t *)&Cla1ProgRunStart, (uint32_t *)&Cla1ProgLoadStart,
            (uint32_t)&Cla1ProgLoadSize);
#if !(CLA_MATH_TABLES_IN_ROM)
    //
    // Copy over CLA Math tables from FLASH to RAM
    //
    memcpy((uint32_t *)&CLA1mathTablesRunStart, (uint32_t *)&CLA1mathTablesLoadStart,
            (uint32_t)&CLA1mathTablesLoadSize);
#endif
    InitFlash();                                                                     // Call the flash wrapper init function
#endif //(FLASH)
       DINT;                                                                         // Disable CPU interrupts
       InitPieCtrl();                                                                // Initialize the PIE control registers to their default state.
       IER = 0x0000;                                                                 // Disable CPU interrupts and clear all CPU interrupt flags:
       IFR = 0x0000;
       //i2c_Config();                                                                 //configuring I2C
       //rtc_Init();                                                                   //configuring RTC
       InitPieVectTable();
       EALLOW;                                                                       // This is needed to write to EALLOW protected register
       PieVectTable.TINT0 = &cpu_timer0_isr;                                         //Enable Timer Interrupt for Timer 0
       //PieVectTable.ADCINT1 = &adc_isr;
       //PieVectTable.CLA1_INT1 = &cla1_isr1;
       //PieVectTable.CLA1_INT2 = &cla1_isr2;
       //PieVectTable.CLA1_INT3 = &cla1_isr3;
       //PieVectTable.CLA1_INT5 = &cla1_isr5;
       //PieVectTable.EPWM2_INT = &epwm2_isr;
       //PieVectTable.EPWM3_INT = &epwm3_isr;
       //PieVectTable.EPWM4_INT = &epwm4_isr;
       //PieVectTable.EPWM5_INT = &epwm5_isr;
       EDIS;
       IER |= M_INT1;                                                                  // Enable CPU Interrupt 1
       PieCtrlRegs.PIEIER1.bit.INTx7 = 1;                                            //Timer 0 interrupt Enable at INT 7
       //PieCtrlRegs.PIEIER1.bit.INTx1 = 1;
       //PieCtrlRegs.PIEIER3.bit.INTx2 = 1;
       //PieCtrlRegs.PIEIER3.bit.INTx3 = 1;
       //PieCtrlRegs.PIEIER3.bit.INTx4 = 1;
       //PieCtrlRegs.PIEIER3.bit.INTx5 = 1;
       //PieCtrlRegs.PIEIER11.bit.INTx1 = 1;
       //PieCtrlRegs.PIEIER11.bit.INTx2 = 1;
       //PieCtrlRegs.PIEIER11.bit.INTx3 = 1;
       //PieCtrlRegs.PIEIER11.bit.INTx4 = 1;
       //PieCtrlRegs.PIEIER11.bit.INTx5 = 1;
       /*EALLOW;
       SysCtrlRegs.PCLKCR0.bit.TBCLKSYNC = 0;
       EDIS;*/


       /*InitEPwm2Example();
       DELAY_US(5000);
       InitEPwm3Example();
       DELAY_US(5000);
       InitEPwm4Example();
       DELAY_US(5000);*/


       /*EALLOW;
       SysCtrlRegs.PCLKCR0.bit.TBCLKSYNC = 1;
       EDIS;*/// This is needed to disable write to EALLOW protected registers
       init_cla();
       InitCpuTimers();                                                              // For this example, only initialize the Cpu Timers
       ConfigCpuTimer(&CpuTimer0, 80, 2000);                                      //Configuring Timer 0 for 900ms with 80MHZ Frequency
       CpuTimer0Regs.TCR.all = 0x4001;                                               // Use write-only instruction to set TSS bit = 0
       //InitAdc();  // For this example, init the ADC
       //AdcOffsetSelfCal();
       //(&adcConfig)();


       EINT;                                                                         // Enable Global interrupt INTM
       ERTM;



       InitializeLCD();                                                              //Initializing LCD
       wait_delay();                                                                 //wait........................
       wait_delay();                                                                 //wait........................
       //startup_Initialization();                                                     //calling function for initializing the data on startup
       WriteCommandLCD(0x40+8);                                                      //Up key symbol upload to LCD memory
       for(in=0;in<=7;in++){
           WriteDataLCD(pattern[in]);
       }
       DELAY_US(2000);
       WriteCommandLCD(0x40+16);                                                     //Down Key symbol upload to LCD memory
       for(in=0;in<=7;in++){
           WriteDataLCD(pattern1[in]);
       }
       DELAY_US(2000);
       WriteCommandLCD(0x40+24);                                                     //Enter key symbol upload to LCD memory
       for(in=0;in<=7;in++){
           WriteDataLCD(pattern2[in]);
       }
       DELAY_US(2000);
       //s1();
       (&s1)();                                                                     //calling start-up screen (need to xamine)





       while(1){

       }
}
//-----------------------------------------------------------------------------------------------------------------------------------
//***************************Function Defining Section*******************************************************************************
__interrupt void cpu_timer0_isr(void)                                //Timer 0 Interrupt Function
{
   CpuTimer0.InterruptCount++;
   PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;
}
__interrupt void adc_isr(void)
{                                                               //ADC ISR



    //
    // Clear ADCINT1 flag reinitialize for next SOC
    //
    AdcRegs.ADCINTFLGCLR.bit.ADCINT1 = 1;

    PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;   // Acknowledge interrupt to PIE

    return;
}

void adcConfig(void){                        //ADC configuration
    EALLOW;
    AdcRegs.ADCCTL1.bit.TEMPCONV    = 0;    //Connect internal temp sensor to channel ADCINA5.
    AdcRegs.ADCCTL2.bit.ADCNONOVERLAP = 1; // Enable non-overlap mode
    //
    // ADCINT1 trips after AdcResults latch
    //
    AdcRegs.ADCCTL1.bit.INTPULSEPOS = 1;
    AdcRegs.INTSEL1N2.bit.INT1E     = 1;  // Enabled ADCINT1
    AdcRegs.INTSEL1N2.bit.INT1CONT  = 0;  // Disable ADCINT1 Continuous mode
    //
    // setup EOC1 to trigger ADCINT1 to fire
    //
    AdcRegs.INTSEL1N2.bit.INT1SEL   = 2;
    AdcRegs.ADCSOC0CTL.bit.CHSEL    = 0;  // set SOC0 channel select to ADCINA5
    AdcRegs.ADCSOC1CTL.bit.CHSEL    = 1;  // set SOC0 channel select to ADCINA5
    AdcRegs.ADCSOC2CTL.bit.CHSEL    = 2;  // set SOC0 channel select to ADCINA5
    //AdcRegs.ADCSOC3CTL.bit.CHSEL    = 3;  // set SOC0 channel select to ADCINA5
    //AdcRegs.ADCSOC4CTL.bit.CHSEL    = 4;  // set SOC0 channel select to ADCINA5

    AdcRegs.ADCSOC0CTL.bit.TRIGSEL  = 13;
    AdcRegs.ADCSOC1CTL.bit.TRIGSEL  = 13;
    AdcRegs.ADCSOC2CTL.bit.TRIGSEL  = 13;
    //AdcRegs.ADCSOC3CTL.bit.TRIGSEL  = 1;
    //AdcRegs.ADCSOC4CTL.bit.TRIGSEL  = 1;

    //
    // set SOC0 S/H Window to 7 ADC Clock Cycles, (6 ACQPS plus 1)
    //
    AdcRegs.ADCSOC0CTL.bit.ACQPS    = 6;
    AdcRegs.ADCSOC1CTL.bit.ACQPS    = 6;
    AdcRegs.ADCSOC2CTL.bit.ACQPS    = 6;
    //AdcRegs.ADCSOC3CTL.bit.ACQPS    = 6;
    //AdcRegs.ADCSOC4CTL.bit.ACQPS    = 6;

    //
    EPwm5Regs.ETSEL.bit.SOCAEN  = 1;        // Enable SOC on A group
    EPwm5Regs.ETSEL.bit.SOCASEL = 4;        // Select SOC from CMPA on upcount
    EPwm5Regs.ETPS.bit.SOCAPRD  = 3;        // Generate pulse on 1st event
    EPwm5Regs.CMPA.half.CMPA    = 0x0080;   // Set compare A value
    EPwm5Regs.TBPRD             = 0xFFFF;   // Set period for ePWM1
    EPwm5Regs.TBCTL.bit.CTRMODE = 0;        // count up and start
    EPwm5Regs.ETSEL.bit.INTSEL = ET_CTR_ZERO;     // Select INT on Zero event
    EPwm5Regs.ETSEL.bit.INTEN = 1;                // Enable INT
    EPwm5Regs.ETPS.bit.INTPRD = ET_3RD;           // Generate INT on 3rd event

    EDIS;

}

void power_on(void){//Initial updating for home screens
    if(scrnctr<=7500 && scur==1){
        scrnctr++;
    }
    if(scrnctr>=7501){
        powerOn=1;
        homescreen=1;
        /*homescreen2[1]=(char)1+48;
        homescreen2[2]=(char)3+48;
        homescreen2[4]=(char)0+48;
        homescreen2[5]=(char)9+48;
        homescreen2[7]=(char)2+48;
        homescreen2[8]=(char)0+48;
        homescreen2[11]=(char)0+48;
        homescreen2[12]=(char)9+48;
        homescreen2[14]=(char)5+48;
        homescreen2[15]=(char)0+48;
        homescreen2[17]=(char)0+48;
        homescreen2[18]=(char)9+48;

        homescreen3[4]=(char)1+48;
        homescreen3[5]=(char)1+48;
        homescreen3[6]=(char)1+48;
        homescreen3[8]=(char)1+48;
        homescreen3[13]=(char)2+48;
        homescreen3[14]=(char)2+48;
        homescreen3[16]=(char)2+48;


        livedata2[0]=(char)1+48;
        livedata2[1]=(char)2+48;
        livedata2[2]=(char)3+48;
        livedata2[4]=(char)5+48;
        livedata2[15]=(char)1+48;
        livedata2[16]=(char)2+48;
        livedata2[18]=(char)3+48;
        livedata3[1]=(char)1+48;
        livedata3[3]=(char)2+48;
        livedata3[4]=(char)4+48;
        livedata3[15]=(char)0+48;
        livedata3[16]=(char)1+48;
        livedata3[18]=(char)2+48;
        livedataIavg2[6]=(char)6+48;
        livedataIavg2[7]=(char)7+48;
        livedataIavg2[8]=(char)8+48;
        livedataIavg2[13]=(char)0+48;
        livedataIavg2[14]=(char)2+48;
        livedataIavg2[16]=(char)5+48;
        livedataIavg3[6]=(char)0+48;
        livedataIavg3[7]=(char)1+48;
        livedataIavg3[8]=(char)2+48;
        livedataIavg3[13]=(char)5+48;
        livedataIavg3[14]=(char)5+48;
        livedataIavg3[16]=(char)1+48;
        livedataPn2[4]=(char)1+48;
        livedataPn2[5]=(char)2+48;
        livedataPn2[6]=(char)8+48;
        livedataPn2[10]=(char)1+48;
        livedataPn2[11]=(char)2+48;
        livedataPn2[12]=(char)8+48;
        livedataPn2[16]=(char)1+48;
        livedataPn2[17]=(char)2+48;
        livedataPn2[18]=(char)8+48;
        livedataPn3[3]=(char)0+48;
        livedataPn3[4]=(char)1+48;
        livedataPn3[6]=(char)5+48;
        livedataPn3[9]=(char)0+48;
        livedataPn3[10]=(char)1+48;
        livedataPn3[12]=(char)5+48;
        livedataPn3[15]=(char)0+48;
        livedataPn3[16]=(char)1+48;
        livedataPn3[18]=(char)5+48;
        livedataTemp2[7]=(char)0+48;
        livedataTemp2[8]=(char)5+48;
        livedataTemp2[9]=(char)0+48;
        livedataTemp3[7]=(char)0+48;
        livedataTemp3[8]=(char)5+48;
        livedataTemp3[9]=(char)0+48;*/
        virtualTimer=0;
        rtc_on=1;
    }
}

Uint16 hex_to_dec(Uint16 rawInput){                                 //Function to convert HEX Data to Decimal Value
    decValue=(((rawInput>>4)*10) + (rawInput & 0x0F));
    return decValue;
}



void search(void){                                     //Algorithm to copy Date Location from EEPROM
    int p=0;
    if(rd_progress==0){
        ee_address=2;
    }
    for(p=0;p<3;p++){
        low_add=ee_address & 0x00FF;
        high_add=(ee_address & 0xFF00)>>8;
        eeprom_read(high_add,low_add);
        DELAY_US(5000);
        Da[p]=eeprom_read(high_add,low_add);
        DELAY_US(5000);
        ee_address=ee_address+1;
    }
    //stage1=1;
}                                                    //**********************************************


void dataValidation(void){                          //Algorithm to validate Data copied
    Da[0]=hex_to_dec(Da[0]);    //Data conversion
    eepromdata0=(char)Da[0]/10+48;
    eepromdata1=(char)Da[0]%10+48;

    Da[1]=hex_to_dec(Da[1]);
    eepromdata2=(char)Da[1]/10+48;
    eepromdata3=(char)Da[1]%10+48;

    Da[2]=hex_to_dec(Da[2]);
    eepromdata4=(char)Da[2]/10+48;
    eepromdata5=(char)Da[2]%10+48;

    if(fieldSetting32[6]==eepromdata0 && fieldSetting32[7]==eepromdata1 && fieldSetting32[9]==eepromdata2 && fieldSetting32[10]==eepromdata3 && fieldSetting32[12]==eepromdata4 && fieldSetting32[13]==eepromdata5){
        read=1;                             //Data validator
        rd_progress=1;
        if(!first_address){
            first_address=ee_address-3;
        }
    }else{
        if(first_address){             //Restart from first address
            ee_address=first_address;
        }else{
            if(!first_address){         //Jump to next address of DDMMYY
                rd_progress=1;
                ee_address+=9;
            }
        }
    }
    //stage2=1;
}                                                 //***************************************************


void getdata(void){                               //Copy fault data from eeprom
    p=3;
    for(p=3;p<12;p++){
        low_add=ee_address & 0x00FF;
        high_add=(ee_address & 0xFF00)>>8;
        eeprom_read(high_add,low_add);
        DELAY_US(5000);
        Da[p]=eeprom_read(high_add,low_add);
        DELAY_US(5000);
        ee_address=ee_address+1;
        Da[p]=hex_to_dec(Da[p]);
    }
    read=0;
}                                                //****************************************************

//                                            convert seperate lcd character to single integer value upto 4 digit


void ChartoDec(char *firstDigit,char *secondDigit,char *thirdDigit,char *decimalpoint,Uint16 *result){//Algorithm to combine different lcd character to single decimal value
    *result=((((*firstDigit-48)*1000)+((*secondDigit-48)*100)+((*thirdDigit-48)*10)+((*decimalpoint-48)*1)));
}
//                                            *******************************************************************

//                                                         Calibration Divide factor updater

void Divi_Fac_Update(Uint16 *adc_V,char *FirstDigit,char *SecondDigit,char *ThirdDigit,Uint16 *D_Fact){
    unsigned int result=((((*FirstDigit-48)*100)+((*SecondDigit-48)*10)+((*ThirdDigit-48)*1)));
    *D_Fact=*adc_V/result;
    sub_shift_field1_disp=0;
    updateDisplay=0;
    sub_fieldsetting1=2;
}

//               ***************************************************************************************************************************

//                  Convert current adc value and divide it by particular divide factor and convert result into appropriate value to be displayed onto the LCD

void calibration_adc_lcd_update(Uint16 *current_adc_Val,char *lcd1,char *lcd2,char *lcd3,char *lcd4,Uint16 *divide_Fac,char *result1,char *result2,char *result3){
    *lcd1=(*current_adc_Val/1000)+48;
    *lcd2=((*current_adc_Val/100)%10)+48;
    *lcd3=((*current_adc_Val/10)%10)+48;
    *lcd4=(*current_adc_Val%10)+48;
    unsigned int temp_Value=*current_adc_Val/(*divide_Fac);
    *result1=(temp_Value/100)+48;
    *result2=((temp_Value/10)%10)+48;
    *result3=(temp_Value%10)+48;
}
//**********************************************************************************************************************************************************
__interrupt void epwm5_isr(void)
{

   // Update the CMPA and CMPB values
   //update_compare(&epwm3_info);

   // Clear INT flag for this timer

   EPwm5Regs.ETCLR.bit.INT = 1;


   // Acknowledge this interrupt to receive more interrupts from group 3
   PieCtrlRegs.PIEACK.all = PIEACK_GROUP3;
}
void init_cla(void){
            EALLOW;
            /*Cla1Regs.MVECT1 = (uint16_t)((uint32_t)&Cla1Task1 -
                                         (uint32_t)&Cla1ProgRunStart);
            Cla1Regs.MVECT2 = (uint16_t)((uint32_t)&Cla1Task2 -
                                         (uint32_t)&Cla1ProgRunStart);
            Cla1Regs.MVECT3 = (uint16_t)((uint32_t)&Cla1Task3 -
                                         (uint32_t)&Cla1ProgRunStart);
            Cla1Regs.MVECT4 = (uint16_t)((uint32_t)&Cla1Task4 -
                                         (uint32_t)&Cla1ProgRunStart);*/
            Cla1Regs.MVECT5 = (uint16_t)((uint32_t)&Cla1Task5 -
                                         (uint32_t)&Cla1ProgRunStart);
            /*Cla1Regs.MVECT6 = (uint16_t)((uint32_t)&Cla1Task6 -
                                         (uint32_t)&Cla1ProgRunStart);
            Cla1Regs.MVECT7 = (uint16_t)((uint32_t)&Cla1Task7 -
                                         (uint32_t)&Cla1ProgRunStart);
            Cla1Regs.MVECT8 = (uint16_t)((uint32_t)&Cla1Task8 -
                                         (uint32_t)&Cla1ProgRunStart);*/
            EDIS;

            //
            // Set task triggers to none
            // Enable all CLA tasks
            //
            EALLOW;
            /*Cla1Regs.MPISRCSEL1.bit.PERINT1SEL  = CLA_INT1_NONE;
            Cla1Regs.MPISRCSEL1.bit.PERINT2SEL  = CLA_INT2_NONE;
            Cla1Regs.MPISRCSEL1.bit.PERINT3SEL  = CLA_INT3_NONE;
            Cla1Regs.MPISRCSEL1.bit.PERINT4SEL  = CLA_INT4_NONE;*/
            Cla1Regs.MPISRCSEL1.bit.PERINT5SEL  = CLA_INT5_EPWM5INT;
            /*Cla1Regs.MPISRCSEL1.bit.PERINT6SEL  = CLA_INT6_NONE;
            Cla1Regs.MPISRCSEL1.bit.PERINT7SEL  = CLA_INT7_NONE;
            Cla1Regs.MPISRCSEL1.bit.PERINT8SEL  = CLA_INT8_NONE;*/
            Cla1Regs.MIER.all                   = M_INT5;
            EDIS;

            //
            // Switch the CLA program space to the CLA and enable software forcing
            // Also switch over CLA data RAM 0 and 1
            //
            EALLOW;
            Cla1Regs.MMEMCFG.bit.PROGE  = 1;
            Cla1Regs.MCTL.bit.IACKE     = 1;
            Cla1Regs.MMEMCFG.bit.RAM0E  = 1;
            Cla1Regs.MMEMCFG.bit.RAM1E  = 1;
            EDIS;



}
__interrupt void cla1_isr5(){
    //
    // Clear ADCINT2 flag reinitialize for next SOC
    //
    //AdcRegs.ADCINTFLGCLR.bit.ADCINT2 = 1;


    PieCtrlRegs.PIEACK.all = PIEACK_GROUP11;
}
/*__interrupt void cla1_isr1(){
    //
    // Clear ADCINT2 flag reinitialize for next SOC
    //
    //AdcRegs.ADCINTFLGCLR.bit.ADCINT2 = 1;
    claIntNumber=~claIntNumber;

    PieCtrlRegs.PIEACK.all = PIEACK_GROUP11;
}*/


/*__interrupt void cla1_isr2(){
    //
    // Clear ADCINT2 flag reinitialize for next SOC
    //
    //AdcRegs.ADCINTFLGCLR.bit.ADCINT2 = 1;
    claIntNumber=2;

    PieCtrlRegs.PIEACK.all = PIEACK_GROUP11;
}

__interrupt void cla1_isr3(){
    //
    // Clear ADCINT2 flag reinitialize for next SOC
    //
    //AdcRegs.ADCINTFLGCLR.bit.ADCINT2 = 1;
    claIntNumber=3;

    PieCtrlRegs.PIEACK.all = PIEACK_GROUP11;
}

__interrupt void cla1_isr4(){
    //
    // Clear ADCINT2 flag reinitialize for next SOC
    //
    //AdcRegs.ADCINTFLGCLR.bit.ADCINT2 = 1;
    claIntNumber=4;

    PieCtrlRegs.PIEACK.all = PIEACK_GROUP11;
}
void done(void)
{
    for(;;)
    {
    }
}*/
/*__interrupt void epwm2_isr(void)
{

   // Update the CMPA and CMPB values
   //update_compare(&epwm2_info);

   // Clear INT flag for this timer
   pwmint=2;
   EPwm2Regs.ETCLR.bit.INT = 1;


   // Acknowledge this interrupt to receive more interrupts from group 3
   PieCtrlRegs.PIEACK.all = PIEACK_GROUP3;
}

__interrupt void epwm3_isr(void)
{

   // Update the CMPA and CMPB values
   //update_compare(&epwm3_info);

   // Clear INT flag for this timer
   pwmint=3;
   EPwm3Regs.ETCLR.bit.INT = 1;


   // Acknowledge this interrupt to receive more interrupts from group 3
   PieCtrlRegs.PIEACK.all = PIEACK_GROUP3;
}
__interrupt void epwm4_isr(void)
{

   // Update the CMPA and CMPB values
   //update_compare(&epwm3_info);

   // Clear INT flag for this timer
   pwmint=4;
   EPwm4Regs.ETCLR.bit.INT = 1;


   // Acknowledge this interrupt to receive more interrupts from group 3
   PieCtrlRegs.PIEACK.all = PIEACK_GROUP3;
}





void InitEPwm2Example()
{
    // Setup TBCLK
    EPwm2Regs.TBCTL.bit.CTRMODE = TB_COUNT_UP; // Count up
    EPwm2Regs.TBPRD =4500;       // Set timer period
    EPwm2Regs.TBCTL.bit.PHSEN = TB_DISABLE;    // Disable phase loading
    EPwm2Regs.TBPHS.half.TBPHS = 0000;       // Phase is 0
    EPwm2Regs.TBCTR = 0x0000;                  // Clear counter
    EPwm2Regs.TBCTL.bit.HSPCLKDIV = 0x00;   // Clock ratio to SYSCLKOUT
    EPwm2Regs.TBCTL.bit.CLKDIV = 0x05;
    EPwm2Regs.TBCTL.bit.SYNCOSEL = TB_CTR_ZERO;

    // Setup shadow register load on ZERO
    EPwm2Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;
    EPwm2Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;
    EPwm2Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO;
    EPwm2Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO;

    // Set Compare values
    EPwm2Regs.CMPA.half.CMPA = EPWM2_MIN_CMPA;       // Set compare A value
    EPwm2Regs.CMPB = EPWM2_MAX_CMPB;                 // Set Compare B value

    // Set actions
    EPwm2Regs.AQCTLA.bit.PRD = AQ_CLEAR;             // Clear PWM2A on Period
    EPwm2Regs.AQCTLA.bit.CAU = AQ_SET;               // Set PWM2A on event A, up count

    //EPwm2Regs.AQCTLB.bit.PRD = AQ_CLEAR;             // Clear PWM2B on Period
    //EPwm2Regs.AQCTLB.bit.CBU = AQ_SET;               // Set PWM2B on event B, up count

    // Interrupt where we will change the Compare Values
    EPwm2Regs.ETSEL.bit.INTSEL = ET_CTR_ZERO;        // Select INT on Zero event
    EPwm2Regs.ETSEL.bit.INTEN = 1;                   // Enable INT
    EPwm2Regs.ETPS.bit.INTPRD = ET_3RD;              // Generate INT on 3rd event

    // Information this example uses to keep track
    // of the direction the CMPA/CMPB values are
    // moving, the min and max allowed values and
    // a pointer to the correct ePWM registers
    epwm2_info.EPwm_CMPA_Direction = EPWM_CMP_UP;    // Start by increasing CMPA
    epwm2_info.EPwm_CMPB_Direction = EPWM_CMP_DOWN;  // and decreasing CMPB
    epwm2_info.EPwmTimerIntCount = 0;                // Zero the interrupt counter
    epwm2_info.EPwmRegHandle = &EPwm2Regs;           // Set the pointer to the ePWM module
    epwm2_info.EPwmMaxCMPA = 0xFFFE;         // Setup min/max CMPA/CMPB values
    epwm2_info.EPwmMinCMPA = 0x50;
    epwm2_info.EPwmMaxCMPB = 0xFFFE;
    epwm2_info.EPwmMinCMPB = 0x50;

}

void InitEPwm3Example()
{



    // Setup TBCLK
    EPwm3Regs.TBCTL.bit.CTRMODE = TB_COUNT_UP; // Count up
    EPwm3Regs.TBPRD =4500;       // Set timer period
    EPwm3Regs.TBCTL.bit.PHSEN = TB_ENABLE;    // Disable phase loading
    EPwm3Regs.TBPHS.half.TBPHS = 3000;       // Phase is 0
    EPwm3Regs.TBCTR = 0x0000;                  // Clear counter
    EPwm3Regs.TBCTL.bit.HSPCLKDIV = 0x00;   // Clock ratio to SYSCLKOUT
    EPwm3Regs.TBCTL.bit.CLKDIV = 0x05;
    EPwm3Regs.TBCTL.bit.SYNCOSEL = TB_SYNC_IN;

    // Setup shadow register load on ZERO
    EPwm3Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;
    EPwm3Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;
    EPwm3Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO;
    EPwm3Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO;

   // Set Compare values
    EPwm3Regs.CMPA.half.CMPA = EPWM3_MIN_CMPA; // Set compare A value
    EPwm3Regs.CMPB = EPWM3_MAX_CMPB;           // Set Compare B value

    // Set Actions
    EPwm3Regs.AQCTLA.bit.CAU = AQ_SET;         // Set PWM3A on event B, up count
    EPwm3Regs.AQCTLA.bit.PRD = AQ_CLEAR;


    //EPwm3Regs.AQCTLB.bit.ZRO = AQ_TOGGLE;      // Toggle EPWM3B on Zero

    // Interrupt where we will change the Compare Values
    EPwm3Regs.ETSEL.bit.INTSEL = ET_CTR_ZERO;     // Select INT on Zero event
    EPwm3Regs.ETSEL.bit.INTEN = 1;                // Enable INT
    EPwm3Regs.ETPS.bit.INTPRD = ET_3RD;           // Generate INT on 3rd event

    // Start by increasing the compare A and decreasing compare B
    epwm3_info.EPwm_CMPA_Direction = EPWM_CMP_UP;
    epwm3_info.EPwm_CMPB_Direction = EPWM_CMP_DOWN;
    // Start the cout at 0
    epwm3_info.EPwmTimerIntCount = 0;
    epwm3_info.EPwmRegHandle = &EPwm3Regs;
    epwm3_info.EPwmMaxCMPA = 0xFFFE;
    epwm3_info.EPwmMinCMPA = 0x50;
    epwm3_info.EPwmMaxCMPB = 0xFFFE;
    epwm3_info.EPwmMinCMPB = 0x50;
}


void InitEPwm4Example()
{



    // Setup TBCLK
    EPwm4Regs.TBCTL.bit.CTRMODE = TB_COUNT_UP; // Count up
    EPwm4Regs.TBPRD =4500;       // Set timer period
    EPwm4Regs.TBCTL.bit.PHSEN = TB_ENABLE;    // Disable phase loading
    EPwm4Regs.TBPHS.half.TBPHS = 3000;       // Phase is 0
    EPwm4Regs.TBCTR = 0x0000;                  // Clear counter
    EPwm4Regs.TBCTL.bit.HSPCLKDIV = 0x00;   // Clock ratio to SYSCLKOUT
    EPwm4Regs.TBCTL.bit.CLKDIV = 0x05;
    EPwm4Regs.TBCTL.bit.SYNCOSEL = TB_SYNC_IN;

    // Setup shadow register load on ZERO
    EPwm4Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;
    EPwm4Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;
    EPwm4Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO;
    EPwm4Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO;

   // Set Compare values
    EPwm4Regs.CMPA.half.CMPA = EPWM3_MIN_CMPA; // Set compare A value
    EPwm4Regs.CMPB = EPWM3_MAX_CMPB;           // Set Compare B value

    // Set Actions
    EPwm4Regs.AQCTLA.bit.CAU = AQ_SET;         // Set PWM3A on event B, up count
    EPwm4Regs.AQCTLA.bit.PRD = AQ_CLEAR;


    //EPwm3Regs.AQCTLB.bit.ZRO = AQ_TOGGLE;      // Toggle EPWM3B on Zero

    // Interrupt where we will change the Compare Values
    EPwm4Regs.ETSEL.bit.INTSEL = ET_CTR_ZERO;     // Select INT on Zero event
    EPwm4Regs.ETSEL.bit.INTEN = 1;                // Enable INT
    EPwm4Regs.ETPS.bit.INTPRD = ET_3RD;           // Generate INT on 3rd event

    // Start by increasing the compare A and decreasing compare B
    epwm3_info.EPwm_CMPA_Direction = EPWM_CMP_UP;
    epwm3_info.EPwm_CMPB_Direction = EPWM_CMP_DOWN;
    // Start the cout at 0
    epwm3_info.EPwmTimerIntCount = 0;
    epwm3_info.EPwmRegHandle = &EPwm3Regs;
    epwm3_info.EPwmMaxCMPA = 0xFFFE;
    epwm3_info.EPwmMinCMPA = 0x50;
    epwm3_info.EPwmMaxCMPB = 0xFFFE;
    epwm3_info.EPwmMinCMPB = 0x50;
}*/
